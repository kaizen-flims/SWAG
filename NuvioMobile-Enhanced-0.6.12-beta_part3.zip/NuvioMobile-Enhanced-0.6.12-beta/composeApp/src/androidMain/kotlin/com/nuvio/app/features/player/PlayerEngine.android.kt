package com.nuvio.app.features.player

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.text.SpannableString
import android.net.Uri
import android.util.Log
import android.util.TypedValue
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.Toast
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import com.nuvio.app.features.streams.redactedForLogs
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import nuvio.composeapp.generated.resources.*
import org.jetbrains.compose.resources.getString
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.VideoSize
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.TransferListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.ForwardingAudioSink
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.decoder.ffmpeg.FfmpegAudioRenderer
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.ForwardingRenderer
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.audio.AudioRendererEventListener
import androidx.media3.exoplayer.mediacodec.MediaCodecInfo
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.LoadEventInfo
import androidx.media3.exoplayer.source.MediaLoadData
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.text.TextOutput
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.video.VideoRendererEventListener
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.extractor.ts.TsExtractor
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import androidx.media3.ui.CaptionStyleCompat
import com.nuvio.app.features.autosync.AutoSyncExtractorsFactory
import com.nuvio.app.features.autosync.AutoSyncPreferencesRepository
import com.nuvio.app.features.autosync.LIBMPV_AUTOSYNC_FILE_PREFIX
import com.nuvio.app.features.autosync.rememberAutoSyncCoordinator
import com.nuvio.app.features.player.aiostreams.AiostreamsAss
import com.nuvio.app.features.player.aiostreams.AiostreamsAssEngine
import com.nuvio.app.features.player.anime.AnimeShaderStatusTracker
import com.nuvio.app.features.player.anime.AnimeShaders
import com.nuvio.app.features.player.bluray.BlurayPlaybackSession
import com.nuvio.app.features.player.swdecoder.SoftwareVideoRenderer
import com.nuvio.app.features.autosync.rememberLibmpvAutoSyncCoordinator
import com.nuvio.app.R
import com.nuvio.app.core.logging.InAppLogger
import com.nuvio.app.features.streams.normalizeStreamType
import `is`.xyz.mpv.MPV
import `is`.xyz.mpv.MPVNode
import `is`.xyz.mpv.Utils
import com.nuvio.tv.libass.media.widget.AssSubtitleSurfaceView
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import java.io.IOException
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

private const val TAG = "NuvioPlayer"
private const val PLAYER_DIAGNOSTIC_TAG = "NuvioPlayerDiag"

private class PlaybackDiagnostics {
    var prepareStartedAtMs: Long = 0L
    var attempt: Int = 0
}

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
actual fun PlatformPlayerSurface(
    sourceUrl: String,
    sourceAudioUrl: String?,
    sourceHeaders: Map<String, String>,
    sourceResponseHeaders: Map<String, String>,
    externalSubtitles: List<com.nuvio.app.features.streams.StreamSubtitle>,
    streamType: String?,
    useYoutubeChunkedPlayback: Boolean,
    modifier: Modifier,
    playWhenReady: Boolean,
    initialPositionMs: Long?,
    initialPositionRequestKey: String?,
    resizeMode: PlayerResizeMode,
    playbackEngine: AndroidPlaybackEngine?,
    animeContent: Boolean,
    useNativeController: Boolean,
    discPlaybackEnabled: Boolean,
    liveStream: Boolean,
    onInitialPositionHandled: (key: String, handled: Boolean) -> Unit,
    onControllerReady: (PlayerEngineController) -> Unit,
    onSnapshot: (PlayerPlaybackSnapshot) -> Unit,
    onError: (String?) -> Unit,
) {
    val playerSettings = remember {
        PlayerSettingsRepository.ensureLoaded()
        PlayerSettingsRepository.uiState.value
    }
    val playerSourceKey = listOf(
        sourceUrl,
        sourceAudioUrl.orEmpty(),
        sanitizePlaybackHeaders(sourceHeaders),
        sanitizePlaybackResponseHeaders(sourceResponseHeaders),
        normalizeStreamType(streamType).orEmpty(),
        useYoutubeChunkedPlayback,
        initialPositionRequestKey.orEmpty(),
    )

    val castBridge = rememberPlayerCastBridge(enabled = !useYoutubeChunkedPlayback)
    if (castBridge != null) {
        SideEffect {
            castBridge.bind(
                source = PlayerCastSource(
                    url = sourceUrl,
                    audioUrl = sourceAudioUrl,
                    responseHeaders = sanitizePlaybackResponseHeaders(sourceResponseHeaders),
                    streamType = streamType,
                    initialPositionMs = initialPositionMs,
                ),
                snapshotSink = onSnapshot,
                controllerSink = onControllerReady,
            )
        }
    }
    val surfaceOnControllerReady: (PlayerEngineController) -> Unit =
        if (castBridge != null) castBridge::onLocalControllerReady else onControllerReady
    val surfaceOnSnapshot: (PlayerPlaybackSnapshot) -> Unit =
        if (castBridge != null) castBridge::onLocalSnapshot else onSnapshot
    val surfaceOnError: (String?) -> Unit = { message ->
        if (message == null || castBridge?.isCasting != true) onError(message)
    }

    val requestedEngine = playbackEngine ?: playerSettings.androidPlaybackEngine
    val activeEngine by remember(playerSourceKey, requestedEngine) {
        mutableStateOf(requestedEngine.initialAndroidEngine())
    }

    LaunchedEffect(activeEngine, playerSourceKey, requestedEngine) {
        InAppLogger.info(
            "Player/Android",
            "engine=$activeEngine configured=$requestedEngine url=${InAppLogger.redactUrl(sourceUrl)} " +
                "audio=${!sourceAudioUrl.isNullOrBlank()} subtitles=${externalSubtitles.size} " +
                "streamType=${normalizeStreamType(streamType) ?: "unknown"}",
        )
    }

    when (activeEngine) {
        ResolvedAndroidPlaybackEngine.ExoPlayer -> ExoPlayerSurface(
            sourceUrl = sourceUrl,
            sourceAudioUrl = sourceAudioUrl,
            sourceHeaders = sourceHeaders,
            sourceResponseHeaders = sourceResponseHeaders,
            externalSubtitles = externalSubtitles,
            streamType = streamType,
            useYoutubeChunkedPlayback = useYoutubeChunkedPlayback,
            modifier = modifier,
            playWhenReady = playWhenReady && castBridge?.isCasting != true,
            initialPositionMs = initialPositionMs,
            initialPositionRequestKey = initialPositionRequestKey,
            resizeMode = resizeMode,
            useNativeController = useNativeController,
            animeContent = animeContent,
            discPlaybackEnabled = discPlaybackEnabled,
            liveStream = liveStream,
            onInitialPositionHandled = onInitialPositionHandled,
            onControllerReady = surfaceOnControllerReady,
            onSnapshot = surfaceOnSnapshot,
            onError = surfaceOnError,
        )
        ResolvedAndroidPlaybackEngine.Libmpv -> {
            LaunchedEffect(initialPositionRequestKey) {
                initialPositionRequestKey?.let { key ->
                    onInitialPositionHandled(key, false)
                }
            }
            LibmpvPlayerSurface(
                sourceUrl = sourceUrl,
                sourceAudioUrl = sourceAudioUrl,
                sourceHeaders = sourceHeaders,
                externalSubtitles = externalSubtitles,
                modifier = modifier,
                playWhenReady = playWhenReady && castBridge?.isCasting != true,
                resizeMode = resizeMode,
                videoOutput = playerSettings.androidLibmpvVideoOutput,
                hardwareDecodingEnabled = playerSettings.androidLibmpvHardwareDecodingEnabled,
                yuv420pEnabled = playerSettings.androidLibmpvYuv420pEnabled,
                animeUpscaleEnabled = animeContent && playerSettings.androidAnimeUpscaleEnabled,
                animeLineSharpenEnabled = animeContent && playerSettings.androidAnimeLineSharpenEnabled,
                animeContent = animeContent,
                preferredSubtitleLanguage = playerSettings.preferredSubtitleLanguage,
                onControllerReady = surfaceOnControllerReady,
                onSnapshot = surfaceOnSnapshot,
                onError = surfaceOnError,
            )
        }
    }
    if (castBridge != null) {
        PlayerCastOverlay(bridge = castBridge, modifier = modifier)
    }
}

private enum class ResolvedAndroidPlaybackEngine {
    ExoPlayer,
    Libmpv,
}

private fun AndroidPlaybackEngine.initialAndroidEngine(): ResolvedAndroidPlaybackEngine =
    when (this) {
        AndroidPlaybackEngine.Auto,
        AndroidPlaybackEngine.ExoPlayer -> ResolvedAndroidPlaybackEngine.ExoPlayer
        AndroidPlaybackEngine.Libmpv -> ResolvedAndroidPlaybackEngine.Libmpv
    }

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
private fun ExoPlayerSurface(
    sourceUrl: String,
    sourceAudioUrl: String?,
    sourceHeaders: Map<String, String>,
    sourceResponseHeaders: Map<String, String>,
    externalSubtitles: List<com.nuvio.app.features.streams.StreamSubtitle>,
    streamType: String?,
    useYoutubeChunkedPlayback: Boolean,
    modifier: Modifier,
    playWhenReady: Boolean,
    initialPositionMs: Long?,
    initialPositionRequestKey: String?,
    resizeMode: PlayerResizeMode,
    useNativeController: Boolean,
    animeContent: Boolean,
    discPlaybackEnabled: Boolean,
    liveStream: Boolean,
    onInitialPositionHandled: (key: String, handled: Boolean) -> Unit,
    onControllerReady: (PlayerEngineController) -> Unit,
    onSnapshot: (PlayerPlaybackSnapshot) -> Unit,
    onError: (String?) -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val latestOnSnapshot = rememberUpdatedState(onSnapshot)
    val latestOnError = rememberUpdatedState(onError)
    val latestAnimeContent = rememberUpdatedState(animeContent)
    val latestOnInitialPositionHandled = rememberUpdatedState(onInitialPositionHandled)
    val latestPlayWhenReady = rememberUpdatedState(playWhenReady)
    val coroutineScope = rememberCoroutineScope()

    val playerSettings = remember {
        PlayerSettingsRepository.ensureLoaded()
        PlayerSettingsRepository.uiState.value
    }

    val sanitizedSourceHeaders = remember(sourceHeaders) {
        sanitizePlaybackHeaders(sourceHeaders)
    }
    val sanitizedSourceResponseHeaders = remember(sourceResponseHeaders) {
        sanitizePlaybackResponseHeaders(sourceResponseHeaders)
    }
    val normalizedStreamType = remember(streamType) {
        normalizeStreamType(streamType)
    }
    val useLibmpvAss = playerSettings.useLibmpvAss && AiostreamsAss.isAvailable
    val useLibass = playerSettings.useLibass && !useLibmpvAss
    val aiostreamsAss = remember {
        if (useLibmpvAss) AiostreamsAssEngine(context, playerSettings.tunnelingEnabled) else null
    }
    val libassRenderMode = playerSettings.libassRenderMode
    val playerSourceKey = listOf(
        sourceUrl,
        sourceAudioUrl.orEmpty(),
        sanitizedSourceHeaders,
        sanitizedSourceResponseHeaders,
        normalizedStreamType.orEmpty(),
        useYoutubeChunkedPlayback,
        initialPositionRequestKey.orEmpty(),
    )
    // Tracks whether an ASS track was actively selected and video effects need activation.
    // When this flips to true, the player remember key changes and player rebuilds with effects.
    var videoEffectsNeeded by remember(playerSourceKey) { mutableStateOf(false) }
    var animeRebuildGeneration by remember(playerSourceKey) { mutableStateOf(0) }
    var animeEnhancementStatus by remember(playerSourceKey) { mutableStateOf<AnimeEnhancementStatus?>(null) }
    val animeStatusTracker = remember(playerSourceKey) {
        val mainHandler = Handler(android.os.Looper.getMainLooper())
        AnimeShaderStatusTracker { status -> mainHandler.post { animeEnhancementStatus = status } }
    }
    val exoVideoEffects = remember(playerSourceKey) { ExoVideoEffectsHolder() }
    val playbackDiagnostics = remember(playerSourceKey) { PlaybackDiagnostics() }
    var subtitleDelayMs by remember(playerSourceKey) { mutableStateOf(0) }
    var selectedExternalSubtitleMimeType by remember(playerSourceKey) { mutableStateOf<String?>(null) }
    // Addon subtitle attached by media reload. A player rebuild (libass VIDEO_EFFECT) prepares
    // resolvedMediaItem again, so it must carry this subtitle or the selection is lost.
    var attachedAddonSubtitleConfig by remember(playerSourceKey) {
        mutableStateOf<MediaItem.SubtitleConfiguration?>(null)
    }
    val latestSubtitleDelayMs = rememberUpdatedState(subtitleDelayMs)
    // Read by the loading and playback threads; outlives player rebuilds of the same surface.
    val audioDelayUs = remember { AtomicLong(0L) }
    // Read by the playback thread's audio sink; every rebuilt player picks up the current gain.
    val audioAmplificationDb = remember { AtomicInteger(AUDIO_AMPLIFICATION_MIN_DB) }
    val centerMixLevelDb = remember { AtomicInteger(0) }
    // The current player's FFmpeg audio renderer, for center mix changes during playback.
    val ffmpegAudioRenderer = remember { AtomicReference<FfmpegAudioRenderer?>(null) }
    val latestExternalSubtitleMimeType = rememberUpdatedState(selectedExternalSubtitleMimeType)
    var playerViewRef by remember { mutableStateOf<PlayerView?>(null) }
    var videoAspectRatio by remember(playerSourceKey) { mutableStateOf(0f) }
    val latestVideoAspectRatio = rememberUpdatedState(videoAspectRatio)
    var currentSubtitleStyle by remember { mutableStateOf(SubtitleStyleState.DEFAULT) }
    val subtitlePresenter = remember(playerSourceKey) { SubtitleCuePresenter { currentSubtitleStyle } }
    var sidecarControllerRef by remember { mutableStateOf<SidecarSubtitleController?>(null) }
    val subtitleStyleGuard = remember { SubtitleStyleGuard() }
    var decoderPriorityOverride by remember(playerSourceKey) { mutableStateOf<Int?>(null) }
    var fallbackStartPositionMs by remember(playerSourceKey) { mutableStateOf<Long?>(null) }
    var initializedVideoDecoderName by remember(playerSourceKey) { mutableStateOf<String?>(null) }
    var initializedAudioDecoderName by remember(playerSourceKey) { mutableStateOf<String?>(null) }
    var playerChapters by remember(playerSourceKey) { mutableStateOf<List<PlayerChapter>>(emptyList()) }
    var chaptersProbeDone by remember(playerSourceKey) { mutableStateOf(false) }
    var playbackResumeGeneration by remember(playerSourceKey) { mutableStateOf(0) }
    val stallSession = remember(playerSourceKey) { PlaybackReopenSession(initialPositionMs) }
    val effectiveDecoderPriority = decoderPriorityOverride ?: playerSettings.decoderPriority
    val volumeBoostAudioProcessor = remember(playerSourceKey) {
        PlayerOutputAudioProcessor(stereoDownmixEnabled = !playerSettings.androidAudioPassthroughEnabled).apply {
            nightModeEnabled = playerSettings.nightModeButtonEnabled && playerSettings.nightModeEnabled
        }
    }
    LaunchedEffect(volumeBoostAudioProcessor) {
        PlayerSettingsRepository.uiState
            .map { it.nightModeButtonEnabled && it.nightModeEnabled }
            .distinctUntilChanged()
            .collect { volumeBoostAudioProcessor.nightModeEnabled = it }
    }

    var resolvedMediaItem by remember(playerSourceKey, externalSubtitles) {
        mutableStateOf(
            playbackMediaItemFromUrl(
                url = sourceUrl,
                responseHeaders = sanitizedSourceResponseHeaders,
                streamType = normalizedStreamType,
            ).buildUpon()
                .setMediaId(sourceUrl)
                .apply {
                    val subtitleConfigs = startupSubtitleConfigurations(externalSubtitles)
                    if (subtitleConfigs.isNotEmpty()) {
                        setSubtitleConfigurations(subtitleConfigs)
                    }
                }
                .build(),
        )
    }

    var probeAttempted by remember(playerSourceKey) { mutableStateOf(false) }

    val isLocalFileSource = remember(resolvedMediaItem) {
        resolvedMediaItem.isLocalFileSource()
    }

    val extractorsFactory = remember(sourceUrl, liveStream) {
        DefaultExtractorsFactory()
            .setTsExtractorFlags(
                DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS or liveTsExtractorFlags(liveStream),
            )
            .setTsExtractorTimestampSearchBytes(1500 * TsExtractor.TS_PACKET_SIZE)
            .let { factory -> // AutoSync hook: no observation while disabled.
                AutoSyncPreferencesRepository.ensureLoaded()
                if (AutoSyncPreferencesRepository.preferredSubtitleAutoSyncOnStart.value) {
                    AutoSyncExtractorsFactory(factory, sourceUrl)
                } else factory
            }
            .let { factory -> aiostreamsAss?.extractors(factory) ?: factory }
    }
    val networkBytesRead = remember(playerSourceKey) { AtomicLong(0L) }
    val networkSpeedSampler = remember(playerSourceKey) { ByteRateSampler() }
    val dataSourceFactory = remember(
        context,
        sourceUrl,
        sanitizedSourceHeaders,
        sanitizedSourceResponseHeaders,
        useYoutubeChunkedPlayback,
        externalSubtitles,
        liveStream,
    ) {
        val loopbackSource = isLoopbackPlaybackSource(sourceUrl)
        PlatformPlaybackDataSourceFactory.create(
            context = context,
            defaultRequestHeaders = sanitizedSourceHeaders,
            defaultResponseHeaders = sanitizedSourceResponseHeaders,
            useYoutubeChunkedPlayback = useYoutubeChunkedPlayback,
            useLongReadTimeout = loopbackSource,
            externalSubtitles = externalSubtitles,
        ).let { factory ->
            val hls = playbackMediaItemFromUrl(
                url = sourceUrl,
                responseHeaders = sanitizedSourceResponseHeaders,
                streamType = normalizedStreamType,
            ).localConfiguration?.mimeType == MimeTypes.APPLICATION_M3U8
            if (hls) HlsParameterSetInitDataSource.Factory(factory) else factory
        }.withPlaybackBuffering(
            context = context,
            settings = playerSettings,
            // A live channel never ends and never repeats: the VOD disk cache would replay an old
            // session's bytes and then ask the server for a byte range, and read-ahead only adds delay.
            bufferedUrls = if (liveStream || useYoutubeChunkedPlayback || isLoopbackPlaybackSource(sourceUrl)) {
                emptySet()
            } else {
                listOfNotNull(sourceUrl, sourceAudioUrl?.takeIf { it.isNotBlank() })
                    .filter {
                        isProgressivePlaybackSource(it, sanitizedSourceResponseHeaders, normalizedStreamType)
                    }
                    .toSet()
            },
        ).countingNetworkBytes(networkBytesRead)
    }
    val bluraySession = remember(playerSourceKey, discPlaybackEnabled) {
        val adaptive = normalizedStreamType in setOf("hls", "m3u8", "dash", "mpd", "smoothstreaming", "ss")
        if (!discPlaybackEnabled || !sourceAudioUrl.isNullOrBlank() || useYoutubeChunkedPlayback || adaptive) {
            null
        } else {
            BlurayPlaybackSession(
                sourceUrl = sourceUrl,
                metadataFactory = PlatformPlaybackDataSourceFactory.create(
                    context = context,
                    defaultRequestHeaders = sanitizedSourceHeaders,
                    defaultResponseHeaders = sanitizedSourceResponseHeaders,
                    useYoutubeChunkedPlayback = false,
                    useLongReadTimeout = isLoopbackPlaybackSource(sourceUrl),
                ),
            )
        }
    }
    var discSnapshotVersion by remember(playerSourceKey) { mutableStateOf(0) }

    LaunchedEffect(playerSourceKey) {
        InAppLogger.info(
            "ExoPlayer/Android",
            "prepare source url=${InAppLogger.redactUrl(sourceUrl)} audio=${!sourceAudioUrl.isNullOrBlank()} " +
                "subtitles=${externalSubtitles.size} requestHeaders=${InAppLogger.headerKeys(sanitizedSourceHeaders)} " +
                "responseHeaderOverrides=${InAppLogger.headerKeys(sanitizedSourceResponseHeaders)} " +
                "streamType=${normalizedStreamType ?: "unknown"} youtubeChunked=$useYoutubeChunkedPlayback",
        )
    }

    fun ExoPlayer.setPlaybackMediaItem(videoMediaItem: MediaItem, startPositionMs: Long? = null) {
        val discSource = bluraySession?.mediaSource(dataSourceFactory, videoMediaItem)
        if (discSource != null) {
            val delayedSource = AudioDelayMediaSource(discSource, audioDelayUs::get)
            if (startPositionMs != null) {
                setMediaSource(delayedSource, startPositionMs.coerceAtLeast(0L))
            } else {
                setMediaSource(delayedSource)
            }
        } else if (!sourceAudioUrl.isNullOrBlank()) {
            // AIOStreams ASS scripts keep their own parser; otherwise reuse the libass factory so
            // addon ASS subtitles render the same way as sources the player builds itself.
            val mediaSourceFactory = aiostreamsAss?.let { ass ->
                DefaultMediaSourceFactory(dataSourceFactory, extractorsFactory)
                    .apply { setSubtitleParserFactory(ass.scripts()) }
            } ?: getAssMediaSourceFactoryCompat()
                ?: DefaultMediaSourceFactory(dataSourceFactory, extractorsFactory)
            val videoSource = mediaSourceFactory.createMediaSource(videoMediaItem)
            val audioSource = mediaSourceFactory.createMediaSource(playbackMediaItemFromUrl(sourceAudioUrl))
            val mergedSource = AudioDelayMediaSource(MergingMediaSource(videoSource, audioSource), audioDelayUs::get)
            if (startPositionMs != null) {
                setMediaSource(mergedSource, startPositionMs.coerceAtLeast(0L))
            } else {
                setMediaSource(mergedSource)
            }
        } else if (liveStream) {
            setMediaSource(
                AudioDelayMediaSource(
                    createLiveMediaSource(dataSourceFactory, extractorsFactory, videoMediaItem),
                    audioDelayUs::get,
                ),
            )
        } else if (startPositionMs != null) {
            setMediaItem(videoMediaItem, startPositionMs.coerceAtLeast(0L))
        } else {
            setMediaItem(videoMediaItem)
        }
    }

    val exoPlayer = remember(
        sourceUrl,
        sourceAudioUrl,
        sanitizedSourceHeaders,
        sanitizedSourceResponseHeaders,
        normalizedStreamType,
        useYoutubeChunkedPlayback,
        effectiveDecoderPriority,
        initialPositionRequestKey,
        videoEffectsNeeded,
        animeRebuildGeneration,
        liveStream,
    ) {
        aiostreamsAss?.reset(
            PlatformPlaybackDataSourceFactory.create(
                context = context,
                defaultRequestHeaders = sanitizedSourceHeaders,
                defaultResponseHeaders = sanitizedSourceResponseHeaders,
                useYoutubeChunkedPlayback = false,
                useLongReadTimeout = isLoopbackPlaybackSource(sourceUrl),
            ),
        )
        // Bluetooth headphones and speakers are stereo: decode audio with FFmpeg and mix surround
        // down to a clean 2.0, so dialogue keeps its level against music and effects.
        val bluetoothOutput = context.isMediaOutputBluetooth()
        val audioDownmix = when {
            bluetoothOutput -> FfmpegAudioDownmix(
                channels = AudioOutputChannels.CHANNELS_2_0,
                normalize = !playerSettings.maintainOriginalAudioOnDownmix,
            )
            playerSettings.effectiveDownmixEnabled -> FfmpegAudioDownmix(
                channels = playerSettings.audioOutputChannels,
                normalize = !playerSettings.maintainOriginalAudioOnDownmix,
            )
            else -> null
        }
        Log.i(TAG, "Audio downmix: ${audioDownmix?.channels?.settingValue ?: "off"} (bluetooth=$bluetoothOutput)")
        val renderersFactory = SubtitleOffsetRenderersFactory(
            context = context,
            subtitleDelayUsProvider = { latestSubtitleDelayMs.value.toLong() * 1_000L },
            audioDelayUsProvider = audioDelayUs::get,
            audioAmplificationDbProvider = audioAmplificationDb::get,
            audioDownmix = audioDownmix,
            preferAppAudioDecoder = bluetoothOutput,
            centerMixLevelDbProvider = centerMixLevelDb::get,
            onFfmpegAudioRenderer = ffmpegAudioRenderer::set,
            shouldNormalizeCuePositionProvider = {
                latestExternalSubtitleMimeType.value == MimeTypes.TEXT_VTT
            },
            shouldStripSdhProvider = { currentSubtitleStyle.stripSdh },
            volumeBoostAudioProcessor = volumeBoostAudioProcessor,
            audioPassthroughEnabled = playerSettings.androidAudioPassthroughEnabled,
            presentCues = { cues ->
                val format = playerViewRef?.player?.currentTracks?.groups
                    ?.firstOrNull { it.type == C.TRACK_TYPE_TEXT && it.isSelected }
                    ?.getTrackFormat(0)
                if (sidecarControllerRef?.isSidecarActive() == true) emptyList()
                else subtitlePresenter.present(cues, format?.sampleMimeType != MimeTypes.TEXT_SSA && format?.codecs != MimeTypes.TEXT_SSA)
            },
            videoBoundsFractionProvider = {
                playerViewRef?.videoBoundsFraction(latestVideoAspectRatio.value)
            },
        )
            .setExtensionRendererMode(effectiveDecoderPriority)
            .setEnableDecoderFallback(true)
            .setMapDV7ToHevc(playerSettings.mapDV7ToHevc)

        val trackSelector = DefaultTrackSelector(context).apply {
            var parameters = buildUponParameters()
                .setAllowInvalidateSelectionsOnRendererCapabilitiesChange(true)
            if (playerSettings.tunnelingEnabled) {
                parameters = parameters.setTunnelingEnabled(true)
            }
            val captioningManager = context.getSystemService(Context.CAPTIONING_SERVICE)
                as? android.view.accessibility.CaptioningManager
            if (captioningManager != null) {
                if (!runCatching { captioningManager.isEnabled }.getOrDefault(false)) {
                    parameters = parameters.setIgnoredTextSelectionFlags(
                        parameters.build().ignoredTextSelectionFlags or C.SELECTION_FLAG_DEFAULT
                    )
                }
                runCatching { captioningManager.locale }.getOrNull()?.let { locale ->
                    parameters = parameters.setPreferredTextLanguage(locale.isO3Language)
                }
            }
            if (playerSettings.subtitleStyle.useForcedSubtitles) {
                parameters = parameters.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            } else {
                parameters = parameters.setIgnoredTextSelectionFlags(
                    parameters.build().ignoredTextSelectionFlags or C.SELECTION_FLAG_FORCED
                )
            }
            setParameters(parameters)
        }

        val loadControl = playerSettings.buildPlaybackLoadControl(localFileSource = isLocalFileSource)
            .let { control -> if (liveStream) LiveStartLoadControl(control) else control }

        val liveAnimeSettings = PlayerSettingsRepository.uiState.value
        val animeUpscaleEnabled = latestAnimeContent.value && liveAnimeSettings.androidAnimeUpscaleEnabled
        val animeLineSharpenEnabled = latestAnimeContent.value && liveAnimeSettings.androidAnimeLineSharpenEnabled
        val animeVideoEffects = if (playerSettings.tunnelingEnabled) {
            emptyList()
        } else {
            AnimeShaders.exoVideoEffects(
                context = context,
                upscaleEnabled = animeUpscaleEnabled,
                lineSharpenEnabled = animeLineSharpenEnabled,
                statusTracker = animeStatusTracker,
            )
        }

        InAppLogger.info(
            "ExoPlayer/Android",
            "Initializing ExoPlayer decoderPriority=${effectiveDecoderPriority.decoderPriorityName()} " +
                "decoderFallback=true tunneling=${playerSettings.tunnelingEnabled} libass=$useLibass " +
                "libassRenderMode=$libassRenderMode mapDV7ToHevc=${playerSettings.mapDV7ToHevc} " +
                "animeUpscale=$animeUpscaleEnabled " +
                "animeLineSharpen=$animeLineSharpenEnabled " +
                "animeEffects=${animeVideoEffects.isNotEmpty()}",
        )

        // Audio focus is handled by PlayerAudioFocus, so a denied request (e.g. during a call)
        // doesn't stop playback.
        val playerBuilder = ExoPlayer.Builder(context)
            .setAudioAttributes(playbackAudioAttributes, false)
            .setTrackSelector(trackSelector)
            .setLoadControl(loadControl)

        val player = if (useLibass) {
            // Set render scale before building the player
            val scaleValue = when (playerSettings.libassRenderScale) {
                "THREE_QUARTER" -> 0.75f
                "HALF" -> 0.5f
                "THIRD" -> 0.33f
                "QUARTER" -> 0.25f
                else -> 1.0f
            }
            com.nuvio.tv.libass.media.AssHandler.setRenderScale(scaleValue)
            playerBuilder.buildWithAssSupportCompat(
                context = context,
                dataSourceFactory = dataSourceFactory,
                extractorsFactory = extractorsFactory,
                renderersFactory = renderersFactory,
                audioDelayUsProvider = audioDelayUs::get,
            ).also { builtPlayer ->
                // Apply video effects only when ASS track was detected as selected.
                // On first init videoEffectsNeeded is false. When onTracksChanged
                // detects a selected ASS track, it flips to true which triggers a
                // player rebuild via the remember key.
                var assVideoEffects = emptyList<Effect>()
                if (videoEffectsNeeded) {
                    val effectiveMode = when {
                        playerSettings.tunnelingEnabled -> "OVERLAY"
                        animeVideoEffects.isNotEmpty() -> "VIDEO_EFFECT"
                        else -> playerSettings.libassRenderMode
                    }
                    if (effectiveMode != "OVERLAY") {
                        builtPlayer.getAssHandlerCompat()?.let { handler ->
                            assVideoEffects = listOf(com.nuvio.tv.libass.media.effect.AssVideoEffectAsync(handler))
                        }
                    }
                }
                val videoEffects = animeVideoEffects + assVideoEffects
                if (videoEffects.isNotEmpty()) {
                    builtPlayer.setVideoEffects(videoEffects)
                }
                exoVideoEffects.update(
                    pipelineConfigured = videoEffects.isNotEmpty(),
                    animeBuilt = animeVideoEffects.isNotEmpty(),
                    upscaleEnabled = animeUpscaleEnabled,
                    lineSharpenEnabled = animeLineSharpenEnabled,
                )
            }
        } else {
            val mediaSourceFactory = DefaultMediaSourceFactory(
                dataSourceFactory,
                extractorsFactory,
            )
            aiostreamsAss?.let { mediaSourceFactory.setSubtitleParserFactory(it.scripts()) }

            playerBuilder
                .setRenderersFactory(renderersFactory)
                .setMediaSourceFactory(AudioDelayMediaSourceFactory(mediaSourceFactory, audioDelayUs::get))
                .build()
                .also { builtPlayer ->
                    if (animeVideoEffects.isNotEmpty()) {
                        builtPlayer.setVideoEffects(animeVideoEffects)
                    }
                    exoVideoEffects.update(
                        pipelineConfigured = animeVideoEffects.isNotEmpty(),
                        animeBuilt = animeVideoEffects.isNotEmpty(),
                        upscaleEnabled = animeUpscaleEnabled,
                        lineSharpenEnabled = animeLineSharpenEnabled,
                    )
                }
        }

        player.applySubtitleTrackPreferences(
            preferredLanguage = playerSettings.preferredSubtitleLanguage,
            useForcedSubtitles = playerSettings.subtitleStyle.useForcedSubtitles,
            autoSelectionApplied = false,
            hasActiveSubtitle = false,
            useCustomSubtitles = false,
        )
        player
    }

    val nowPlayingController = remember(context, exoPlayer) {
        AndroidPlayerNowPlayingController(
            context = context,
            controls = AndroidPlayerNowPlayingController.PlaybackControls(
                play = {
                    exoPlayer.playWhenReady = true
                    exoPlayer.play()
                },
                pause = exoPlayer::pause,
                seekTo = { positionMs -> exoPlayer.seekTo(positionMs.coerceAtLeast(0L)) },
                seekBy = { offsetMs ->
                    exoPlayer.seekTo((exoPlayer.currentPosition + offsetMs).coerceAtLeast(0L))
                },
            ),
        )
    }

    val exoMediaInfoCache = remember(exoPlayer) { ExoMediaInfoCache() }
    val liveEdgeRejoin = remember(exoPlayer) { if (liveStream) LiveEdgeRejoin() else null }

    fun dispatchExoPlayerSnapshot() {
        val snapshot = exoPlayer.snapshot(
            initializedVideoDecoderName,
            initializedAudioDecoderName,
            playerChapters,
            exoMediaInfoCache,
        ).copy(animeEnhancement = animeEnhancementStatus)
            .let { base ->
                val session = bluraySession
                if (session == null || !session.hasTitles) {
                    base
                } else {
                    val extra = session.isExtraPlaying
                    base.copy(
                        isEnded = base.isEnded && !extra,
                        discTitles = session.titles(),
                        activeDiscTitleIndex = session.activeIndex,
                        discExtraPlaying = extra,
                        discFeaturePositionMs = session.featurePositionMs,
                    )
                }
            }
        latestOnSnapshot.value(snapshot)
        nowPlayingController.syncPlayback(snapshot)
    }

    LaunchedEffect(exoPlayer, playerSourceKey) {
        if (chaptersProbeDone || useYoutubeChunkedPlayback) return@LaunchedEffect
        if (!PlayerSettingsRepository.uiState.value.androidExoChaptersEnabled) return@LaunchedEffect
        if (!isProgressivePlaybackSource(sourceUrl, sanitizedSourceResponseHeaders, normalizedStreamType)) {
            return@LaunchedEffect
        }
        while (
            exoPlayer.playbackState != Player.STATE_READY ||
            exoPlayer.duration == C.TIME_UNSET ||
            exoPlayer.isCurrentMediaItemLive
        ) {
            delay(500)
        }
        val chapterDataSourceFactory = PlatformPlaybackDataSourceFactory.create(
            context = context,
            defaultRequestHeaders = sanitizedSourceHeaders,
            defaultResponseHeaders = sanitizedSourceResponseHeaders,
            useYoutubeChunkedPlayback = false,
            useLongReadTimeout = isLoopbackPlaybackSource(sourceUrl),
        )
        val chapters = withTimeoutOrNull(20_000L) {
            PlayerChapterReader.read(sourceUrl, chapterDataSourceFactory)
        }.orEmpty()
        chaptersProbeDone = true
        if (chapters.isNotEmpty()) {
            playerChapters = chapters
            dispatchExoPlayerSnapshot()
        }
    }

    DisposableEffect(nowPlayingController) {
        onDispose { nowPlayingController.release() }
    }

    val audioFocus = remember(context, exoPlayer) {
        PlayerAudioFocus(
            context = context,
            playWhenReady = { exoPlayer.playWhenReady },
            pause = exoPlayer::pause,
            resume = exoPlayer::play,
        )
    }

    DisposableEffect(audioFocus) {
        onDispose { audioFocus.abandon() }
    }

    LaunchedEffect(exoPlayer, resolvedMediaItem, initialPositionRequestKey, playbackResumeGeneration) {
        val mediaItem = attachedAddonSubtitleConfig?.let { config ->
            resolvedMediaItem.buildUpon().setSubtitleConfigurations(listOf(config)).build()
        } ?: resolvedMediaItem
        InAppLogger.info(
            "ExoPlayer/Android",
            "load mediaItem uri=${InAppLogger.redactUrl(mediaItem.localConfiguration?.uri?.toString() ?: sourceUrl)} " +
                "mime=${mediaItem.localConfiguration?.mimeType ?: "unknown"} startPositionMs=${fallbackStartPositionMs ?: 0L}",
        )
        val requestedStartPositionMs = stallSession.prepareStartPositionMs(fallbackStartPositionMs)
        val mediaMimeType = mediaItem.localConfiguration?.mimeType
        if (bluraySession != null && mediaMimeType != MimeTypes.APPLICATION_M3U8 &&
            mediaMimeType != MimeTypes.APPLICATION_MPD && mediaMimeType != MimeTypes.APPLICATION_SS
        ) {
            if (bluraySession.resolveBeforePlayback() != null) {
                InAppLogger.info("ExoPlayer/Android", "Blu-ray source detected url=${InAppLogger.redactUrl(sourceUrl)}")
                discSnapshotVersion += 1
            }
        }
        playbackDiagnostics.attempt += 1
        playbackDiagnostics.prepareStartedAtMs = SystemClock.elapsedRealtime()
        Log.i(
            PLAYER_DIAGNOSTIC_TAG,
            "prepare begin attempt=${playbackDiagnostics.attempt} " +
                "source=${diagnosticPlaybackSource(sourceUrl)} audioSource=${!sourceAudioUrl.isNullOrBlank()} " +
                "mime=${mediaItem.localConfiguration?.mimeType ?: "auto"} " +
                "startPositionMs=${requestedStartPositionMs ?: 0L}",
        )
        exoPlayer.setPlaybackMediaItem(mediaItem, requestedStartPositionMs)
        exoPlayer.prepare()
        if (!stallSession.isReopening(fallbackStartPositionMs)) {
            initialPositionRequestKey?.let { key ->
                latestOnInitialPositionHandled.value(
                    key,
                    requestedStartPositionMs != null,
                )
            }
        }
    }

    val pendingSubtitleTrackIndex = remember { mutableListOf<Int>() }
    val pendingAudioTrackSelection = remember { mutableListOf<TrackSelectionSnapshot>() }
    var subtitleSelectionJob by remember { mutableStateOf<Job?>(null) }
    val isInPip = rememberIsInPictureInPicture()
    // Player size outside PiP, so PiP subtitles keep the full-screen size relative to the video.
    var playerSizeOutsidePip by remember { mutableStateOf(IntSize.Zero) }
    val pipVideoHeightPx by rememberUpdatedState(
        if (isInPip) displayedVideoHeightPx(playerSizeOutsidePip, exoPlayer.videoSize) ?: 0f else null,
    )

    val sidecarController = remember(exoPlayer, coroutineScope) {
        SidecarSubtitleController(
            scope = coroutineScope,
            getPlayer = { exoPlayer },
            getSubtitleDelayMs = { latestSubtitleDelayMs.value },
            getAudioDelayUs = audioDelayUs::get,
            presentCues = { cues -> subtitlePresenter.present(cues, sidecarControllerRef?.subtitleMimeType != MimeTypes.TEXT_SSA) },
        ).also { sidecarControllerRef = it }
    }

    val autoSyncCoordinator = rememberAutoSyncCoordinator( // AutoSync hook
        scope = coroutineScope,
        player = exoPlayer,
        sidecar = sidecarController,
        playerSourceKey = playerSourceKey,
        sourceUrl = sourceUrl,
        sourceHeaders = sanitizedSourceHeaders,
        externalSubtitles = externalSubtitles,
        useLibass = useLibass || useLibmpvAss,
        preferredSubtitleLanguage = playerSettings.preferredSubtitleLanguage,
        onMimeTypeSelected = { selectedExternalSubtitleMimeType = it },
        onSubtitleDelayChanged = { subtitleDelayMs = it },
    )

    fun syncPlayerViewKeepScreenOn() {
        playerViewRef?.keepScreenOn = exoPlayer.shouldKeepPlayerScreenOn()
    }

    fun preserveAudioSelectionForReload(reason: String) {
        pendingAudioTrackSelection.clear()
        val selection = exoPlayer.captureSelectedTrack(C.TRACK_TYPE_AUDIO) ?: return
        pendingAudioTrackSelection.add(selection)
        Log.d(TAG, "$reason: preserving audio track index=${selection.index} id=${selection.id}")
    }

    LaunchedEffect(exoPlayer, animeEnhancementStatus, discSnapshotVersion) {
        dispatchExoPlayerSnapshot()
    }

    fun playDiscTitle(startPositionMs: Long, reason: String) {
        val mediaItem = attachedAddonSubtitleConfig?.let { config ->
            resolvedMediaItem.buildUpon().setSubtitleConfigurations(listOf(config)).build()
        } ?: resolvedMediaItem
        InAppLogger.info(
            "ExoPlayer/Android",
            "Blu-ray $reason title=${bluraySession?.activeIndex} startPositionMs=$startPositionMs",
        )
        exoPlayer.setPlaybackMediaItem(mediaItem, startPositionMs)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
        discSnapshotVersion += 1
    }

    fun returnToDiscFeature(reason: String): Boolean {
        val resumeMs = bluraySession?.returnToFeature() ?: return false
        playDiscTitle(resumeMs, reason)
        return true
    }

    val liveSettings by rememberAnimeToggles()
    LaunchedEffect(
        exoPlayer,
        animeContent,
        liveSettings.androidAnimeUpscaleEnabled,
        liveSettings.androidAnimeLineSharpenEnabled,
    ) {
        val upscale = animeContent && liveSettings.androidAnimeUpscaleEnabled
        val sharpen = animeContent && liveSettings.androidAnimeLineSharpenEnabled
        if (playerSettings.tunnelingEnabled) return@LaunchedEffect
        if (exoVideoEffects.matches(upscale, sharpen)) return@LaunchedEffect
        if (!exoVideoEffects.pipelineConfigured && !upscale && !sharpen) {
            exoVideoEffects.update(
                pipelineConfigured = false,
                animeBuilt = false,
                upscaleEnabled = false,
                lineSharpenEnabled = false,
            )
            return@LaunchedEffect
        }
        delay(ANIME_EFFECTS_REBUILD_DEBOUNCE_MS)
        InAppLogger.info("ExoPlayer/Android", "anime effects changed, rebuilding player upscale=$upscale lineSharpen=$sharpen")
        preserveAudioSelectionForReload("animeEffectsRebuild")
        val selectedSubtitle = exoPlayer.currentTracks.selectedTextTrackOrdinal()
        if (selectedSubtitle >= 0) {
            pendingSubtitleTrackIndex.clear()
            pendingSubtitleTrackIndex.add(selectedSubtitle)
        }
        if (useLibass && (upscale || sharpen) && !videoEffectsNeeded &&
            exoPlayer.currentTracks.hasSelectedAssWithoutDolbyVision()
        ) {
            videoEffectsNeeded = true
        }
        fallbackStartPositionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
        animeRebuildGeneration += 1
    }

    DisposableEffect(exoPlayer) {
        PlayerPictureInPictureManager.registerPausePlaybackCallback {
            exoPlayer.pause()
        }

        fun reportPlayerError(error: PlaybackException) {
            if (
                playerSettings.decoderPriority == DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON &&
                effectiveDecoderPriority != DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER &&
                error.isDecoderFailure()
            ) {
                Log.w(
                    TAG,
                    "Decoder failure (${error.errorCodeName}); retrying with app decoders",
                    error,
                )
                InAppLogger.warn(
                    "ExoPlayer/Android",
                    "Decoder failure ${error.errorCodeName}; retrying with preferred app decoders. " +
                        "cause=${error.cause?.let(InAppLogger::throwableSummary) ?: InAppLogger.throwableSummary(error)}",
                )
                fallbackStartPositionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
                decoderPriorityOverride = DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
                latestOnError.value(null)
                return
            }
            InAppLogger.error(
                "ExoPlayer/Android",
                "Playback error code=${error.errorCodeName} message=${error.localizedMessage ?: error.message ?: "unknown"} " +
                    "cause=${error.cause?.let(InAppLogger::throwableSummary) ?: "none"}",
            )
            latestOnError.value(runBlocking { error.toDisplayMessage() })
        }

        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                syncPlayerViewKeepScreenOn()
                InAppLogger.error(
                    "ExoPlayer/Android",
                    "onPlayerError code=${error.errorCodeName} recoverableProbe=${!probeAttempted} " +
                        "message=${error.localizedMessage ?: error.message ?: "unknown"}",
                )
                Log.e(
                    PLAYER_DIAGNOSTIC_TAG,
                    "error attempt=${playbackDiagnostics.attempt} " +
                        "elapsedMs=${diagnosticElapsedSince(playbackDiagnostics.prepareStartedAtMs)} " +
                        "code=${error.errorCodeName} cause=${error.cause?.javaClass?.simpleName ?: "none"} " +
                        "positionMs=${exoPlayer.currentPosition.coerceAtLeast(0L)} " +
                        "bufferedMs=${exoPlayer.bufferedPosition.coerceAtLeast(0L)} " +
                        "durationMs=${exoPlayer.duration.coerceAtLeast(0L)} " +
                        "message=${diagnosticPlayerMessage(error.message)} " +
                        "causeChain=${diagnosticThrowableChain(error)}",
                    error,
                )

                if (liveEdgeRejoin?.tryRejoin(error, exoPlayer) == true) {
                    InAppLogger.warn("ExoPlayer/Android", "Live stream fell behind its window; rejoining the live edge")
                    latestOnError.value(null)
                    return
                }

                if (bluraySession?.isExtraPlaying == true) {
                    InAppLogger.warn(
                        "ExoPlayer/Android",
                        "Blu-ray extra failed code=${error.errorCodeName}; returning to the feature",
                    )
                    if (returnToDiscFeature("extra failed")) {
                        latestOnError.value(null)
                        Toast.makeText(
                            context,
                            runBlocking { getString(Res.string.player_disc_title_failed) },
                            Toast.LENGTH_SHORT,
                        ).show()
                        return
                    }
                }

                val positionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
                val durationMs = exoPlayer.duration.coerceAtLeast(0L)
                if (
                    stallSession.onFailure(
                        failure = error.toPlaybackSourceFailure(),
                        positionMs = positionMs,
                        durationMs = durationMs,
                    )
                ) {
                    val resumeMs = stallSession.prepareStartPositionMs()
                    Log.w(TAG, "Playback stalled at ${resumeMs}ms. Reopening at that position.")
                    Log.i(
                        PLAYER_DIAGNOSTIC_TAG,
                        "stall resume positionMs=$resumeMs durationMs=$durationMs",
                    )
                    preserveAudioSelectionForReload("stall resume")
                    playbackResumeGeneration = stallSession.resumeGeneration
                    latestOnError.value(null)
                    return
                }

                val isSourceError = error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW ||
                        error.errorCode == PlaybackException.ERROR_CODE_IO_UNSPECIFIED ||
                        error.cause?.toString()?.contains("UnrecognizedInputFormatException") == true ||
                        // A channel link often names no format (or the wrong one): the probe reads what the server sends.
                        (liveStream && error.errorCode in LIVE_PROBE_ERROR_CODES)

                val discSession = bluraySession
                val isContainerError = error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
                    error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
                    error.errorCode == PlaybackException.ERROR_CODE_IO_UNSPECIFIED ||
                    error.cause?.toString()?.contains("UnrecognizedInputFormatException") == true
                if (discSession != null && discSession.canProbeAfterFailure && isContainerError && exoPlayer.duration == C.TIME_UNSET) {
                    val resumeMs = stallSession.prepareStartPositionMs(fallbackStartPositionMs) ?: positionMs
                    coroutineScope.launch {
                        if (discSession.probeAfterFailure() != null) {
                            InAppLogger.warn(
                                "ExoPlayer/Android",
                                "Source error recovered by Blu-ray probe url=${InAppLogger.redactUrl(sourceUrl)}",
                            )
                            latestOnError.value(null)
                            playDiscTitle(resumeMs, "probe")
                            return@launch
                        }
                        handleSourceError(error, isSourceError)
                    }
                    return
                }

                handleSourceError(error, isSourceError)
            }

            private fun handleSourceError(error: PlaybackException, isSourceError: Boolean) {
                if (isSourceError && !stallSession.probeAttempted) {
                    stallSession.markMimeProbe()
                    coroutineScope.launch {
                        val probedMime = withContext(Dispatchers.IO) {
                            probeMimeType(sourceUrl, sanitizedSourceHeaders)
                        }
                        if (probedMime != null && probedMime != resolvedMediaItem.localConfiguration?.mimeType) {
                            Log.d(TAG, "Playback failed with source error. Probed MIME type: $probedMime. Retrying...")
                            InAppLogger.warn(
                                "ExoPlayer/Android",
                                "Source error recovered by MIME probe mime=$probedMime url=${InAppLogger.redactUrl(sourceUrl)}",
                            )
                            resolvedMediaItem = resolvedMediaItem.buildUpon()
                                .setMimeType(probedMime)
                                .build()
                            latestOnError.value(null)
                            return@launch
                        }
                        reportPlayerError(error)
                    }
                    return
                }

                reportPlayerError(error)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                val stateName = when (playbackState) {
                    Player.STATE_IDLE -> "IDLE"
                    Player.STATE_BUFFERING -> "BUFFERING"
                    Player.STATE_READY -> "READY"
                    Player.STATE_ENDED -> "ENDED"
                    else -> "UNKNOWN($playbackState)"
                }
                Log.d(TAG, "onPlaybackStateChanged: $stateName")
                InAppLogger.debug("ExoPlayer/Android", "state=$stateName playWhenReady=${exoPlayer.playWhenReady}")
                Log.i(
                    PLAYER_DIAGNOSTIC_TAG,
                    "state=$stateName attempt=${playbackDiagnostics.attempt} " +
                        "elapsedMs=${diagnosticElapsedSince(playbackDiagnostics.prepareStartedAtMs)} " +
                        "positionMs=${exoPlayer.currentPosition.coerceAtLeast(0L)} " +
                        "bufferedMs=${exoPlayer.bufferedPosition.coerceAtLeast(0L)} " +
                        "durationMs=${exoPlayer.duration.coerceAtLeast(0L)} " +
                        "playWhenReady=${exoPlayer.playWhenReady} " +
                        "terminalError=${exoPlayer.playerError?.errorCodeName ?: "none"}",
                )
                if (playbackState == Player.STATE_ENDED && bluraySession?.isExtraPlaying == true &&
                    returnToDiscFeature("extra ended")
                ) {
                    syncPlayerViewKeepScreenOn()
                    return
                }
                if (playbackState == Player.STATE_READY) {
                    fallbackStartPositionMs = null
                    stallSession.onReady()
                    latestOnError.value(null)
                    exoPlayer.logCurrentTracks("STATE_READY")
                    exoPlayer.logSelectedPlaybackDetails("STATE_READY")
                }
                syncPlayerViewKeepScreenOn()
                dispatchExoPlayerSnapshot()
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (playWhenReady) audioFocus.request()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                InAppLogger.debug("ExoPlayer/Android", "isPlaying=$isPlaying")
                Log.i(
                    PLAYER_DIAGNOSTIC_TAG,
                    "isPlaying=$isPlaying attempt=${playbackDiagnostics.attempt} " +
                        "elapsedMs=${diagnosticElapsedSince(playbackDiagnostics.prepareStartedAtMs)} " +
                        "positionMs=${exoPlayer.currentPosition.coerceAtLeast(0L)}",
                )
                syncPlayerViewKeepScreenOn()
                dispatchExoPlayerSnapshot()
            }

            override fun onRenderedFirstFrame() {
                InAppLogger.info(
                    "ExoPlayer/Android",
                    "firstFrame attempt=${playbackDiagnostics.attempt} " +
                        "elapsedMs=${diagnosticElapsedSince(playbackDiagnostics.prepareStartedAtMs)} " +
                        "positionMs=${exoPlayer.currentPosition.coerceAtLeast(0L)}",
                )
                Log.i(
                    PLAYER_DIAGNOSTIC_TAG,
                    "firstFrame attempt=${playbackDiagnostics.attempt} " +
                        "elapsedMs=${diagnosticElapsedSince(playbackDiagnostics.prepareStartedAtMs)} " +
                        "positionMs=${exoPlayer.currentPosition.coerceAtLeast(0L)}",
                )
            }

            override fun onPlaybackParametersChanged(playbackParameters: androidx.media3.common.PlaybackParameters) {
                InAppLogger.debug(
                    "ExoPlayer/Android",
                    "playbackSpeed=${playbackParameters.speed} pitch=${playbackParameters.pitch}",
                )
                dispatchExoPlayerSnapshot()
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                InAppLogger.info("ExoPlayer/Android", "videoSize=${videoSize.toLogSummary()}")
                if (videoSize.width > 0 && videoSize.height > 0) {
                    // Include anamorphic pixel width so fitted subtitle geometry follows
                    // the display aspect ratio reported by Media3.
                    videoAspectRatio = (
                        videoSize.width.toFloat() * videoSize.pixelWidthHeightRatio
                    ) / videoSize.height.toFloat()
                }
                if (exoVideoEffects.pipelineConfigured) {
                    val sourceFormat = exoPlayer.videoFormat
                    if (sourceFormat != null && sourceFormat.width > 0 && sourceFormat.height > 0) {
                        exoPlayer.getAssHandlerCompat()?.setVideoSize(sourceFormat.width, sourceFormat.height)
                    }
                }
                dispatchExoPlayerSnapshot()
                playerViewRef?.post {
                    playerViewRef?.syncLibassOverlayGeometry()
                }
            }

            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                Log.d(TAG, "onTracksChanged: ${tracks.groups.size} groups total")
                InAppLogger.info("ExoPlayer/Android", "tracksChanged groups=${tracks.groups.size}")
                exoPlayer.logCurrentTracks("onTracksChanged")
                exoPlayer.logSelectedPlaybackDetails("onTracksChanged")
                pendingAudioTrackSelection.firstOrNull()?.let { selection ->
                    if (tracks.groups.any { it.type == C.TRACK_TYPE_AUDIO }) {
                        pendingAudioTrackSelection.clear()
                        val restored = exoPlayer.restoreTrackSelection(selection)
                        Log.d(TAG, "onTracksChanged: restored pending audio selection=$restored")
                    }
                }
                if (pendingSubtitleTrackIndex.isNotEmpty() && tracks.groups.isNotEmpty()) {
                    val idx = pendingSubtitleTrackIndex.removeAt(0)
                    Log.d(TAG, "onTracksChanged: applying pending subtitle selection index=$idx")
                    exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                        .buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, idx < 0)
                        .build()
                    if (idx >= 0) {
                        exoPlayer.selectTrackByIndex(C.TRACK_TYPE_TEXT, idx)
                    }
                }
                // Trigger player rebuild with video effects when ASS track becomes selected
                // and render mode is VIDEO_EFFECT.
                if (!videoEffectsNeeded && useLibass && exoVideoEffects.libassRenderMode(libassRenderMode) != "OVERLAY") {
                    val hasSelectedAss = tracks.groups.any { group ->
                        group.isSelected && group.type == C.TRACK_TYPE_TEXT &&
                            (0 until group.length).any { i ->
                                group.isTrackSelected(i) && group.getTrackFormat(i).isAssSubtitleFormat()
                            }
                    }
                    val hasDvVideo = tracks.groups.any { group ->
                        group.isSelected && group.type == C.TRACK_TYPE_VIDEO &&
                            (0 until group.length).any { i ->
                                group.getTrackFormat(i).sampleMimeType == MimeTypes.VIDEO_DOLBY_VISION
                            }
                    }
                    if (hasSelectedAss && !hasDvVideo) {
                        Log.d(TAG, "onTracksChanged: ASS track selected, triggering video effect rebuild")
                        // Save current subtitle selection to restore after rebuild.
                        // Find the selected text track index in the current tracks.
                        var selectedSubIdx = -1
                        var textIdx = 0
                        for (group in tracks.groups) {
                            if (group.type != C.TRACK_TYPE_TEXT) continue
                            for (i in 0 until group.length) {
                                if (group.isTrackSelected(i)) {
                                    selectedSubIdx = textIdx
                                }
                                textIdx++
                            }
                        }
                        if (selectedSubIdx >= 0) {
                            pendingSubtitleTrackIndex.clear()
                            pendingSubtitleTrackIndex.add(selectedSubIdx)
                        }
                        fallbackStartPositionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
                        videoEffectsNeeded = true
                    }
                }
                dispatchExoPlayerSnapshot()
            }
        }

        val analyticsListener = object : AnalyticsListener {
            private var lastBandwidthLogUptimeMs = 0L

            override fun onVideoDecoderInitialized(
                eventTime: AnalyticsListener.EventTime,
                decoderName: String,
                initializedTimestampMs: Long,
                initializationDurationMs: Long,
            ) {
                initializedVideoDecoderName = decoderName
                InAppLogger.info(
                    "ExoPlayer/Android",
                    "videoDecoder=$decoderName acceleration=${decoderName.decoderAccelerationHint()} initMs=$initializationDurationMs",
                )
                dispatchExoPlayerSnapshot()
            }

            override fun onAudioDecoderInitialized(
                eventTime: AnalyticsListener.EventTime,
                decoderName: String,
                initializedTimestampMs: Long,
                initializationDurationMs: Long,
            ) {
                initializedAudioDecoderName = decoderName
                InAppLogger.info(
                    "ExoPlayer/Android",
                    "audioDecoder=$decoderName acceleration=${decoderName.decoderAccelerationHint()} initMs=$initializationDurationMs",
                )
                dispatchExoPlayerSnapshot()
            }

            override fun onLoadError(
                eventTime: AnalyticsListener.EventTime,
                loadEventInfo: LoadEventInfo,
                mediaLoadData: MediaLoadData,
                error: IOException,
                wasCanceled: Boolean,
            ) {
                InAppLogger.warn(
                    "Network/Playback",
                    "loadError url=${InAppLogger.redactUrl(loadEventInfo.uri.toString())} " +
                        "type=${mediaLoadData.dataType} trackType=${mediaLoadData.trackType} canceled=$wasCanceled " +
                        "error=${InAppLogger.throwableSummary(error)}",
                )
            }

            override fun onBandwidthEstimate(
                eventTime: AnalyticsListener.EventTime,
                totalLoadTimeMs: Int,
                totalBytesLoaded: Long,
                bitrateEstimate: Long,
            ) {
                val now = SystemClock.uptimeMillis()
                if (now - lastBandwidthLogUptimeMs < 5_000L) return
                lastBandwidthLogUptimeMs = now
                InAppLogger.debug(
                    "Network/Playback",
                    "bandwidth bitrate=${bitrateEstimate.formatBitrate()} " +
                        "totalBytes=${totalBytesLoaded.formatBytes()} loadTimeMs=$totalLoadTimeMs",
                )
            }
        }

        exoPlayer.addListener(listener)
        exoPlayer.addAnalyticsListener(analyticsListener)
        onDispose {
            PlayerPictureInPictureManager.registerPausePlaybackCallback(null)
            exoPlayer.removeListener(listener)
            exoPlayer.removeAnalyticsListener(analyticsListener)
            playerViewRef?.keepScreenOn = false
            subtitleSelectionJob?.cancel()
            sidecarController.stopSidecarAddonSubtitle(clearView = true)
        }
    }

    DisposableEffect(exoPlayer, lifecycleOwner) {
        val activity = context.findActivity()
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> {
                    InAppLogger.debug(
                        "ExoPlayer/Android",
                        "lifecycle ON_START restorePlayWhenReady=${latestPlayWhenReady.value}",
                    )
                    exoPlayer.playWhenReady = latestPlayWhenReady.value
                }
                Lifecycle.Event.ON_STOP -> {
                    val isInPictureInPicture =
                        Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && activity?.isInPictureInPictureMode == true
                    val isFinishing = activity?.isFinishing == true
                    InAppLogger.debug(
                        "ExoPlayer/Android",
                        "lifecycle ON_STOP pip=$isInPictureInPicture finishing=$isFinishing positionMs=${exoPlayer.currentPosition.coerceAtLeast(0L)}",
                    )
                    if (!isInPictureInPicture || isFinishing) {
                        exoPlayer.pause()
                    }
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            InAppLogger.info(
                "ExoPlayer/Android",
                "release positionMs=${exoPlayer.currentPosition.coerceAtLeast(0L)} durationMs=${exoPlayer.duration.coerceAtLeast(0L)}",
            )
            playerViewRef?.releaseLibassOverlay()
            exoPlayer.release()
        }
    }

    DisposableEffect(aiostreamsAss) {
        onDispose { aiostreamsAss?.release() }
    }

    DisposableEffect(exoPlayer, aiostreamsAss) {
        aiostreamsAss?.bind(exoPlayer)
        onDispose { aiostreamsAss?.unbind(exoPlayer) }
    }

    LaunchedEffect(aiostreamsAss, subtitleDelayMs) {
        aiostreamsAss?.setSubtitleDelayMs(subtitleDelayMs)
    }

    LaunchedEffect(exoPlayer, playWhenReady) {
        exoPlayer.playWhenReady = latestPlayWhenReady.value
        syncPlayerViewKeepScreenOn()
        dispatchExoPlayerSnapshot()
    }

    LaunchedEffect(exoPlayer) {
        onControllerReady(
            autoSyncCoordinator.wrap(object : PlayerEngineController { // AutoSync hook
                override val playbackEngine = AndroidPlaybackEngine.ExoPlayer

                private var lastAppliedVolume: Float? = null

                override fun networkSpeedBytesPerSecond(): Long? =
                    networkSpeedSampler.sample(networkBytesRead.get(), SystemClock.elapsedRealtime())

                private val audioTrackCache = AudioTrackCache()
                override fun play() {
                    InAppLogger.debug("ExoPlayer/Android", "control play positionMs=${exoPlayer.currentPosition.coerceAtLeast(0L)}")
                    exoPlayer.playWhenReady = true
                    exoPlayer.play()
                }

                // Fork: ExoPlayer chapters come from PlayerChapterReader (MKV + MP4) through the
                // playback snapshot, gated by the upstream "Show Chapters" toggle; see the probe
                // in ExoPlayerSurface. Upstream's MatroskaChapterLoader is not used.

                override fun pause() {
                    InAppLogger.debug("ExoPlayer/Android", "control pause positionMs=${exoPlayer.currentPosition.coerceAtLeast(0L)}")
                    exoPlayer.pause()
                }

                override fun seekTo(positionMs: Long) {
                    val targetMs = positionMs.coerceAtLeast(0L)
                    InAppLogger.info(
                        "ExoPlayer/Android",
                        "control seekTo fromMs=${exoPlayer.currentPosition.coerceAtLeast(0L)} targetMs=$targetMs",
                    )
                    exoPlayer.seekTo(targetMs)
                }

                override fun seekBy(offsetMs: Long) {
                    val currentMs = exoPlayer.currentPosition.coerceAtLeast(0L)
                    val targetMs = (currentMs + offsetMs).coerceAtLeast(0L)
                    InAppLogger.info("ExoPlayer/Android", "control seekBy offsetMs=$offsetMs fromMs=$currentMs targetMs=$targetMs")
                    exoPlayer.seekTo(targetMs)
                }

                override fun retry() {
                    InAppLogger.info("ExoPlayer/Android", "control retry positionMs=${exoPlayer.currentPosition.coerceAtLeast(0L)}")
                    exoPlayer.prepare()
                    exoPlayer.playWhenReady = true
                }

                override fun setPlaybackSpeed(speed: Float) {
                    InAppLogger.info("ExoPlayer/Android", "control speed=$speed")
                    exoPlayer.setPlaybackSpeed(speed)
                }

                override fun setVideoZoom(scale: Float) {
                    val playerView = playerViewRef ?: return
                    val target = playerView
                        .findViewById<View>(androidx.media3.ui.R.id.exo_content_frame)
                        ?: playerView.videoSurfaceView
                        ?: return
                    target.scaleX = scale
                    target.scaleY = scale
                }

                override fun updateNowPlayingMetadata(info: PlayerNowPlayingInfo) {
                    nowPlayingController.updateMetadata(info)
                }

                override fun clearNowPlayingInfo() {
                    nowPlayingController.clear()
                }

                override fun currentPlayerVolume(): PlayerAudioLevel {
                    val current = volumeBoostAudioProcessor.level.coerceIn(0f, 2f)
                    return PlayerAudioLevel(
                        fraction = current,
                        isMuted = current <= 0.001f,
                    )
                }

                override fun setPlayerVolume(level: Float): PlayerAudioLevel {
                    val target = level.coerceIn(0f, 2f)
                    if (target != lastAppliedVolume) {
                        lastAppliedVolume = target
                        exoPlayer.volume = 1f
                        volumeBoostAudioProcessor.level = target
                    }
                    return PlayerAudioLevel(
                        fraction = target,
                        isMuted = target <= 0.001f,
                    )
                }

                override fun getAudioTracks(): List<AudioTrack> =
                    audioTrackCache.tracks(exoPlayer, context)

                override fun selectDiscTitle(index: Int) {
                    val session = bluraySession ?: return
                    val startMs = session.select(index, exoPlayer.currentPosition) ?: return
                    playDiscTitle(startMs, "select")
                }

                override fun loadDiscTitleDetails() {
                    val session = bluraySession ?: return
                    if (!session.hasTitles) return
                    coroutineScope.launch {
                        session.loadLanguages { discSnapshotVersion += 1 }
                    }
                }

                override suspend fun getMediaInfo(): PlayerMediaInfo {
                    val video = exoPlayer.videoFormat
                    val audio = exoPlayer.audioFormat
                    return PlayerMediaInfo(
                        videoCodec = exoVideoCodec(video),
                        videoWidth = video?.width?.takeIf { it > 0 },
                        videoHeight = video?.height?.takeIf { it > 0 },
                        videoFrameRate = video?.frameRate?.takeIf { it > 0f },
                        videoBitrate = video?.bitrate?.takeIf { it > 0 },
                        audioCodec = CustomDefaultTrackNameProvider.formatNameFromMime(audio?.sampleMimeType),
                        audioChannels = audio?.channelCount?.takeIf { it > 0 },
                        audioSampleRate = audio?.sampleRate?.takeIf { it > 0 },
                        audioProfiles = exoAudioProfiles(audio),
                        hdr = video?.hdrFormats().orEmpty(),
                        bitDepth = video?.exoBitDepth(),
                    )
                }

                override fun getSubtitleTracks(): List<SubtitleTrack> {
                    val tracks = exoPlayer.extractSubtitleTracks(context)
                    InAppLogger.debug(
                        "ExoPlayer/Android",
                        "getSubtitleTracks count=${tracks.size} selected=${tracks.firstOrNull { it.isSelected }?.index ?: -1}",
                    )
                    Log.d(TAG, "getSubtitleTracks: found ${tracks.size} tracks")
                    tracks.forEach { t ->
                        Log.d(TAG, "  track idx=${t.index} id=${t.id} label='${t.label}' lang=${t.language} selected=${t.isSelected}")
                    }
                    return tracks
                }

                override fun selectAudioTrack(index: Int) {
                    InAppLogger.info("ExoPlayer/Android", "select audio track index=$index")
                    exoPlayer.selectTrackByIndex(C.TRACK_TYPE_AUDIO, index)
                }

                override fun applyAudioLanguagePreferences(languages: List<String>) {
                    exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                        .buildUpon()
                        .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                        .setPreferredAudioLanguages(*languages.toTypedArray())
                        .build()
                }

                override fun selectSubtitleTrack(index: Int) {
                    InAppLogger.info("ExoPlayer/Android", "select subtitle track index=$index")
                    Log.d(TAG, "selectSubtitleTrack: index=$index")
                    sidecarController.stopSidecarAddonSubtitle(clearView = true)
                    aiostreamsAss?.clearExternal()
                    if (index < 0) {
                        Log.d(TAG, "selectSubtitleTrack: disabling text tracks")
                        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                            .buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                            .build()
                        return
                    }
                    exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                        .buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                        .build()
                    exoPlayer.selectTrackByIndex(C.TRACK_TYPE_TEXT, index)
                    Log.d(TAG, "selectSubtitleTrack: after selection, textDisabled=${exoPlayer.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)}")
                    exoPlayer.logCurrentTracks("after selectSubtitleTrack")
                }

                override fun setSubtitleUri(url: String) {
                    Log.d(TAG, "setSubtitleUri: url=${url.redactedForLogs()}")
                    InAppLogger.info("ExoPlayer/Android", "set external subtitle url=${InAppLogger.redactUrl(url)}")
                    subtitleSelectionJob?.cancel()
                    if (aiostreamsAss != null && PlayerSubtitleUtils.mimeTypeFromUrl(url) == MimeTypes.TEXT_SSA) {
                        sidecarController.stopSidecarAddonSubtitle(clearView = true)
                        val headers = externalSubtitles.firstOrNull { it.url == url }?.headers.orEmpty()
                        subtitleSelectionJob = coroutineScope.launch {
                            if (aiostreamsAss.showExternal(url, headers)) {
                                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                    .buildUpon()
                                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                                    .build()
                            } else {
                                InAppLogger.warn("ExoPlayer/Android", "libmpv ASS could not load url=${InAppLogger.redactUrl(url)}")
                            }
                        }
                        return
                    }
                    if (sidecarController.canAttachAddonSubtitleViaSidecar(url, useLibass)) {
                        Log.d(TAG, "setSubtitleUri: using buffer-preserving sidecar for url=${url.redactedForLogs()}")
                        val headers = externalSubtitles.firstOrNull { it.url == url }?.headers.orEmpty()
                        val attached = sidecarController.startSidecarAddonSubtitle(
                            url = url,
                            headers = headers,
                            useLibass = useLibass,
                        )
                        if (attached) {
                            attachedAddonSubtitleConfig = null
                            exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                .buildUpon()
                                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                                .build()
                            return
                        }
                    }
                    subtitleSelectionJob = coroutineScope.launch {
                        val currentPosition = exoPlayer.currentPosition
                        val wasPlaying = exoPlayer.isPlaying
                        val currentMediaItem = exoPlayer.currentMediaItem ?: run {
                            Log.e(TAG, "setSubtitleUri: currentMediaItem is null, aborting")
                            InAppLogger.warn("ExoPlayer/Android", "set external subtitle aborted: currentMediaItem is null")
                            return@launch
                        }
                        preserveAudioSelectionForReload("setSubtitleUri")
                        val resolvedMime = PlayerSubtitleUtils.mimeTypeFromUrl(url)
                        selectedExternalSubtitleMimeType = resolvedMime
                        InAppLogger.info(
                            "ExoPlayer/Android",
                            "external subtitle resolved mime=$resolvedMime positionMs=$currentPosition wasPlaying=$wasPlaying",
                        )
                        Log.d(TAG, "setSubtitleUri: currentPosition=$currentPosition, wasPlaying=$wasPlaying")
                        val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(markedSubtitleUri(url))
                            .setId(addonSubtitleTrackId(url))
                            .setMimeType(resolvedMime)
                            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                            .setRoleFlags(C.ROLE_FLAG_SUBTITLE)
                            .build()
                        Log.d(
                            TAG,
                            "setSubtitleUri: subtitleConfig built, uri=${url.redactedForLogs()}, mime=${subtitleConfig.mimeType}, selectionFlags=${subtitleConfig.selectionFlags}"
                        )
                        attachedAddonSubtitleConfig = subtitleConfig
                        val newMediaItem = currentMediaItem.buildUpon()
                            .setSubtitleConfigurations(listOf(subtitleConfig))
                            .build()
                        Log.d(TAG, "setSubtitleUri: newMediaItem subtitleConfigs count=${newMediaItem.localConfiguration?.subtitleConfigurations?.size}")
                        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                            .buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                            .setPreferredTextRoleFlags(C.ROLE_FLAG_SUBTITLE)
                            .build()
                        Log.d(TAG, "setSubtitleUri: track params set before prepare, textDisabled=${exoPlayer.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)}")
                        exoPlayer.setPlaybackMediaItem(newMediaItem, currentPosition)
                        exoPlayer.prepare()
                        exoPlayer.playWhenReady = wasPlaying
                        Log.d(TAG, "setSubtitleUri: prepare() called, waiting for STATE_READY")
                    }
                }

                override fun clearExternalSubtitle() {
                    Log.d(TAG, "clearExternalSubtitle called")
                    InAppLogger.info("ExoPlayer/Android", "clear external subtitle")
                    subtitleSelectionJob?.cancel()
                    sidecarController.stopSidecarAddonSubtitle(clearView = true)
                    aiostreamsAss?.clearExternal()
                    selectedExternalSubtitleMimeType = null
                    attachedAddonSubtitleConfig = null
                    val currentPosition = exoPlayer.currentPosition
                    val wasPlaying = exoPlayer.isPlaying
                    val currentMediaItem = exoPlayer.currentMediaItem ?: run {
                        InAppLogger.warn("ExoPlayer/Android", "clear external subtitle aborted: currentMediaItem is null")
                        return
                    }
                    if (currentMediaItem.localConfiguration?.subtitleConfigurations?.isNotEmpty() == true) {
                        preserveAudioSelectionForReload("clearExternalSubtitle")
                        val newMediaItem = currentMediaItem.buildUpon()
                            .setSubtitleConfigurations(emptyList())
                            .build()
                        exoPlayer.setPlaybackMediaItem(newMediaItem, currentPosition)
                        exoPlayer.prepare()
                        exoPlayer.playWhenReady = wasPlaying
                    } else {
                        selectSubtitleTrack(-1)
                    }
                    Log.d(TAG, "clearExternalSubtitle: done, position=$currentPosition")
                }

                override fun clearExternalSubtitleAndSelect(trackIndex: Int) {
                    Log.d(TAG, "clearExternalSubtitleAndSelect: trackIndex=$trackIndex")
                    InAppLogger.info("ExoPlayer/Android", "clear external subtitle and select builtInIndex=$trackIndex")
                    subtitleSelectionJob?.cancel()
                    sidecarController.stopSidecarAddonSubtitle(clearView = true)
                    aiostreamsAss?.clearExternal()
                    selectedExternalSubtitleMimeType = null
                    attachedAddonSubtitleConfig = null
                    val currentPosition = exoPlayer.currentPosition
                    val wasPlaying = exoPlayer.isPlaying
                    val currentMediaItem = exoPlayer.currentMediaItem ?: run {
                        InAppLogger.warn("ExoPlayer/Android", "clear external subtitle/select aborted: currentMediaItem is null")
                        return
                    }
                    if (currentMediaItem.localConfiguration?.subtitleConfigurations?.isNotEmpty() == true) {
                        pendingSubtitleTrackIndex.clear()
                        pendingSubtitleTrackIndex.add(trackIndex)
                        preserveAudioSelectionForReload("clearExternalSubtitleAndSelect")
                        val newMediaItem = currentMediaItem.buildUpon()
                            .setSubtitleConfigurations(emptyList())
                            .build()
                        exoPlayer.setPlaybackMediaItem(newMediaItem, currentPosition)
                        exoPlayer.prepare()
                        exoPlayer.playWhenReady = wasPlaying
                    } else {
                        pendingSubtitleTrackIndex.clear()
                        selectSubtitleTrack(trackIndex)
                    }
                    Log.d(TAG, "clearExternalSubtitleAndSelect: done, pending=$trackIndex position=$currentPosition")
                }

                override fun applySubtitleStyle(style: SubtitleStyleState) {
                    InAppLogger.debug(
                        "ExoPlayer/Android",
                        "apply subtitle style font=${style.fontSizeSp} bold=${style.bold} outline=${style.outlineEnabled}:${style.outlineWidth} bottom=${style.bottomOffset}",
                    )
                    currentSubtitleStyle = style
                    playerViewRef?.subtitleView?.setCues(subtitlePresenter.refresh())
                    playerViewRef?.applySubtitleStyle(style, pipVideoHeightPx)
                }

                override fun applySubtitlePreferences(
                    preferredLanguage: String,
                    secondaryPreferredLanguage: String?,
                    useForcedSubtitles: Boolean,
                    autoSelectionApplied: Boolean,
                    hasActiveSubtitle: Boolean,
                    useCustomSubtitles: Boolean,
                ) {
                    exoPlayer.applySubtitleTrackPreferences(
                        preferredLanguage = preferredLanguage,
                        useForcedSubtitles = useForcedSubtitles,
                        autoSelectionApplied = autoSelectionApplied,
                        hasActiveSubtitle = hasActiveSubtitle,
                        useCustomSubtitles = useCustomSubtitles,
                    )
                }

                override fun setSubtitleDelayMs(delayMs: Int) {
                    val targetMs = delayMs.coerceIn(SUBTITLE_DELAY_MIN_MS, SUBTITLE_DELAY_MAX_MS)
                    InAppLogger.info("ExoPlayer/Android", "set subtitle delay ms=$targetMs")
                    subtitleDelayMs = targetMs
                    exoPlayer.getAssHandlerCompat()?.let {
                        it.subtitleDelayUs = subtitleDelayMs.toLong() * 1000L
                    }
                }

                override val supportsAudioDelay = true

                override fun setAudioDelayMs(delayMs: Int) {
                    val delayUs = delayMs.coerceIn(AUDIO_DELAY_MIN_MS, AUDIO_DELAY_MAX_MS).toLong() * 1000L
                    audioDelayUs.set(delayUs)
                    exoPlayer.getAssHandlerCompat()?.audioDelayUs = delayUs
                }

                override val supportsAudioAmplification = true

                override fun setAudioAmplificationDb(db: Int) {
                    audioAmplificationDb.set(db.coerceIn(AUDIO_AMPLIFICATION_MIN_DB, AUDIO_AMPLIFICATION_MAX_DB))
                }

                override fun isCenterMixActive(): Boolean =
                    ffmpegAudioRenderer.get()?.isCenterMixActive() == true

                override fun setCenterMixLevelDb(db: Int) {
                    val clamped = db.coerceIn(CENTER_MIX_LEVEL_MIN_DB, CENTER_MIX_LEVEL_MAX_DB)
                    centerMixLevelDb.set(clamped)
                    ffmpegAudioRenderer.get()?.setCenterMixLevelDb(clamped)
                }
            }),
        )
    }

    LaunchedEffect(exoPlayer) {
        while (isActive) {
            dispatchExoPlayerSnapshot()
            delay(250L)
        }
    }

    Box(modifier = modifier) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { viewContext ->
                PlayerView(viewContext).apply {
                    useController = useNativeController
                    layoutParams = android.view.ViewGroup.LayoutParams(MATCH_PARENT, MATCH_PARENT)
                    player = exoPlayer
                    keepScreenOn = exoPlayer.shouldKeepPlayerScreenOn()
                    this.resizeMode = resizeMode.toExoResizeMode()
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                    playerViewRef = this
                    sidecarController.bindSubtitleView(this.subtitleView)
                    subtitleView?.addOnLayoutChangeListener { view, _, _, _, _, _, _, _, _ ->
                        val inPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N &&
                            context.findActivity()?.isInPictureInPictureMode == true
                        val size = IntSize(
                            view.width - view.paddingLeft - view.paddingRight,
                            view.height - view.paddingTop - view.paddingBottom,
                        )
                        if (!inPip && size.width > 0 && size.height > 0) playerSizeOutsidePip = size
                    }
                    syncLibassOverlay(
                        player = exoPlayer,
                        enabled = useLibass,
                        renderMode = exoVideoEffects.libassRenderMode(libassRenderMode),
                        tunnelingEnabled = playerSettings.tunnelingEnabled,
                    )
                    aiostreamsAss?.attach(this)
                    aiostreamsAss?.setStyle(currentSubtitleStyle)
                    if (subtitleStyleGuard.shouldApply(this, currentSubtitleStyle, pipVideoHeightPx)) {
                        applySubtitleStyle(currentSubtitleStyle, pipVideoHeightPx)
                    }
                }
            },
            update = { playerView ->
                playerView.player = exoPlayer
                playerView.useController = useNativeController
                playerView.resizeMode = resizeMode.toExoResizeMode()
                playerViewRef = playerView
                sidecarController.bindSubtitleView(playerView.subtitleView)
                syncPlayerViewKeepScreenOn()
                playerView.syncLibassOverlay(
                    player = exoPlayer,
                    enabled = useLibass,
                    renderMode = exoVideoEffects.libassRenderMode(libassRenderMode),
                    tunnelingEnabled = playerSettings.tunnelingEnabled,
                )
                aiostreamsAss?.attach(playerView)
                aiostreamsAss?.setStyle(currentSubtitleStyle)
                if (subtitleStyleGuard.shouldApply(playerView, currentSubtitleStyle, pipVideoHeightPx)) {
                    playerView.applySubtitleStyle(currentSubtitleStyle, pipVideoHeightPx)
                }
            },
        )
        StyledSubtitleOverlay(
            subtitlePresenter.text,
            currentSubtitleStyle,
            videoAspectRatio = videoAspectRatio,
            videoResizeMode = resizeMode,
        )
    }
}

@Composable
private fun LibmpvPlayerSurface(
    sourceUrl: String,
    sourceAudioUrl: String?,
    sourceHeaders: Map<String, String>,
    externalSubtitles: List<com.nuvio.app.features.streams.StreamSubtitle>,
    modifier: Modifier,
    playWhenReady: Boolean,
    resizeMode: PlayerResizeMode,
    videoOutput: AndroidLibmpvVideoOutput,
    hardwareDecodingEnabled: Boolean,
    yuv420pEnabled: Boolean,
    animeUpscaleEnabled: Boolean,
    animeLineSharpenEnabled: Boolean,
    animeContent: Boolean,
    preferredSubtitleLanguage: String?,
    onControllerReady: (PlayerEngineController) -> Unit,
    onSnapshot: (PlayerPlaybackSnapshot) -> Unit,
    onError: (String?) -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val latestOnSnapshot = rememberUpdatedState(onSnapshot)
    val latestOnError = rememberUpdatedState(onError)
    val latestPlayWhenReady = rememberUpdatedState(playWhenReady)
    val coroutineScope = rememberCoroutineScope()
    val playbackDiagnostics = remember { PlaybackDiagnostics() }
    val sanitizedSourceHeaders = remember(sourceHeaders) {
        sanitizePlaybackHeaders(sourceHeaders)
    }
    val autoSyncCoordinator = rememberLibmpvAutoSyncCoordinator( // AutoSync hook
        scope = coroutineScope,
        sourceUrl = sourceUrl,
        sourceHeaders = sanitizedSourceHeaders,
        externalSubtitles = externalSubtitles,
        preferredSubtitleLanguage = preferredSubtitleLanguage,
    )
    var playerViewRef by remember { mutableStateOf<NuvioLibmpvView?>(null) }
    val nowPlayingController = remember(context, playerViewRef) {
        playerViewRef?.let { view ->
            AndroidPlayerNowPlayingController(
                context = context,
                controls = AndroidPlayerNowPlayingController.PlaybackControls(
                    play = { view.setPaused(false) },
                    pause = { view.setPaused(true) },
                    seekTo = { positionMs -> view.seekToMs(positionMs) },
                    seekBy = { offsetMs -> view.seekByMs(offsetMs) },
                ),
            )
        }
    }

    DisposableEffect(nowPlayingController) {
        onDispose { nowPlayingController?.release() }
    }

    val mpvPaused = remember { AtomicBoolean(true) }
    val audioFocus = remember(context) {
        PlayerAudioFocus(
            context = context,
            playWhenReady = { !mpvPaused.get() },
            pause = { playerViewRef?.setPaused(true) },
            resume = { playerViewRef?.setPaused(false) },
        )
    }

    DisposableEffect(audioFocus) {
        onDispose { audioFocus.abandon() }
    }

    DisposableEffect(lifecycleOwner, nowPlayingController) {
        val activity = context.findActivity()
        val observer = LifecycleEventObserver { _, event ->
            val view = playerViewRef ?: return@LifecycleEventObserver
            when (event) {
                Lifecycle.Event.ON_START -> view.setPaused(!latestPlayWhenReady.value)
                Lifecycle.Event.ON_STOP -> {
                    val isInPictureInPicture =
                        Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && activity?.isInPictureInPictureMode == true
                    val isFinishing = activity?.isFinishing == true
                    if (!isInPictureInPicture || isFinishing) {
                        view.setPaused(true)
                    }
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    DisposableEffect(playerViewRef, nowPlayingController) {
        val view = playerViewRef ?: return@DisposableEffect onDispose {}
        fun dispatchSnapshot(updateKeepScreenOn: Boolean = false) {
            coroutineScope.launch(Dispatchers.Main.immediate) {
                val snapshot = view.snapshot()
                latestOnSnapshot.value(snapshot)
                nowPlayingController?.syncPlayback(snapshot)
                if (updateKeepScreenOn) {
                    view.keepScreenOn = snapshot.isPlaying || snapshot.isLoading
                }
            }
        }
        val errorLog = MpvErrorLog()
        val observer = object : MPV.EventObserver {
            override fun eventProperty(property: String) {
                if (property == "sub-text" || property == "sid") view.updateStyledSubtitle()
            }
            override fun eventProperty(property: String, value: Long) {
                if (property == "sid") view.updateStyledSubtitle()
                if (property == "cache-buffering-state") {
                    dispatchSnapshot(updateKeepScreenOn = true)
                }
            }
            override fun eventProperty(property: String, value: Boolean) {
                if (property == "eof-reached" && value) {
                    Log.w(
                        PLAYER_DIAGNOSTIC_TAG,
                        "mpv_property=eof-reached value=true attempt=${playbackDiagnostics.attempt} " +
                            "elapsedMs=${diagnosticElapsedSince(playbackDiagnostics.prepareStartedAtMs)}",
                    )
                }
                if (property == "pause") {
                    mpvPaused.set(value)
                    if (!value) coroutineScope.launch(Dispatchers.Main.immediate) { audioFocus.request() }
                }
                if (property == "eof-reached" || property == "pause" || property == "paused-for-cache" || property == "seeking") {
                    dispatchSnapshot(updateKeepScreenOn = true)
                }
            }
            override fun eventProperty(property: String, value: String) {
                if (property == "video-codec" || property == "audio-codec" || property == "hwdec-current") {
                    InAppLogger.info("MPV/Android", "$property=$value")
                }
                if (property == "sub-text" || property == "sid") view.updateStyledSubtitle()
            }
            override fun eventProperty(property: String, value: Double) {
                if (property == "duration" || property == "time-pos" || property == "speed") {
                    dispatchSnapshot()
                }
            }
            override fun eventProperty(property: String, value: MPVNode) {
                when (property) {
                    "track-list" -> {
                        InAppLogger.info("MPV/Android", "track-list updated")
                        view.refreshTracks(context)
                        view.updateStyledSubtitle()
                        dispatchSnapshot()
                    }
                    "video-params" -> InAppLogger.info("MPV/Android", "videoParams=${value.toMpvNodeSummary()}")
                    "audio-params" -> InAppLogger.info("MPV/Android", "audioParams=${value.toMpvNodeSummary()}")
                }
            }
            override fun event(eventId: Int, data: MPVNode) {
                when (eventId) {
                    MPV.mpvEvent.MPV_EVENT_START_FILE -> {
                        errorLog.clear()
                        Log.i(
                            PLAYER_DIAGNOSTIC_TAG,
                            "mpv_event=START_FILE attempt=${playbackDiagnostics.attempt} " +
                                "elapsedMs=${diagnosticElapsedSince(playbackDiagnostics.prepareStartedAtMs)}",
                        )
                        coroutineScope.launch(Dispatchers.Main.immediate) {
                            latestOnError.value(null)
                            val snapshot = PlayerPlaybackSnapshot()
                            latestOnSnapshot.value(snapshot)
                            nowPlayingController?.syncPlayback(snapshot)
                        }
                    }
                    MPV.mpvEvent.MPV_EVENT_FILE_LOADED,
                    MPV.mpvEvent.MPV_EVENT_PLAYBACK_RESTART -> {
                        if (eventId == MPV.mpvEvent.MPV_EVENT_FILE_LOADED) view.attachStartupSubtitles()
                        coroutineScope.launch(Dispatchers.Main.immediate) {
                            InAppLogger.info(
                                "MPV/Android",
                                "event=$eventId playback ready ${view.playbackDiagnosticsForLogs()}",
                            )
                            latestOnError.value(null)
                            val snapshot = view.snapshot()
                            Log.i(
                                PLAYER_DIAGNOSTIC_TAG,
                                "mpv_event=${if (eventId == MPV.mpvEvent.MPV_EVENT_FILE_LOADED) "FILE_LOADED" else "PLAYBACK_RESTART"} " +
                                    "attempt=${playbackDiagnostics.attempt} " +
                                    "elapsedMs=${diagnosticElapsedSince(playbackDiagnostics.prepareStartedAtMs)} " +
                                    "positionMs=${snapshot.positionMs} bufferedMs=${snapshot.bufferedPositionMs} " +
                                    "durationMs=${snapshot.durationMs}",
                            )
                            latestOnSnapshot.value(snapshot)
                            nowPlayingController?.syncPlayback(snapshot)
                        }
                    }
                    MPV.mpvEvent.MPV_EVENT_END_FILE -> {
                        val endReason = data.nodeString("reason")
                        val fileError = data.nodeString("file_error")
                        val endFileJson = data.toJson()
                        coroutineScope.launch(Dispatchers.Main.immediate) {
                            val snapshot = view.snapshot()
                            Log.w(
                                PLAYER_DIAGNOSTIC_TAG,
                                "mpv_event=END_FILE attempt=${playbackDiagnostics.attempt} " +
                                    "elapsedMs=${diagnosticElapsedSince(playbackDiagnostics.prepareStartedAtMs)} " +
                                    "positionMs=${snapshot.positionMs} bufferedMs=${snapshot.bufferedPositionMs} " +
                                    "durationMs=${snapshot.durationMs} eof=${snapshot.isEnded} " +
                                    "data=${diagnosticPlayerMessage(endFileJson)}",
                            )
                            InAppLogger.info("MPV/Android", "event=end-file")
                            latestOnSnapshot.value(snapshot)
                            nowPlayingController?.syncPlayback(snapshot)
                            view.keepScreenOn = snapshot.isPlaying || snapshot.isLoading
                            if (endReason.equals("error", ignoreCase = true)) {
                                Log.e(
                                    PLAYER_DIAGNOSTIC_TAG,
                                    "mpv_error attempt=${playbackDiagnostics.attempt} " +
                                        "fileError=${diagnosticPlayerMessage(fileError)}",
                                )
                                val logLine = errorLog.logLine()
                                val httpCode = mpvHttpStatusCode(logLine)
                                val codecContext = if (httpCode == null) {
                                    runCatching { mpvCodecContextLine(view.mpv, logLine.orEmpty()) }.getOrNull()
                                } else {
                                    null
                                }
                                latestOnError.value(
                                    mpvErrorMessage(
                                        fileError = fileError,
                                        logLine = logLine,
                                        codecContext = codecContext,
                                        fallback = getString(Res.string.player_unable_to_play_stream),
                                        httpExplanation = httpCode?.let { httpStatusExplanationText(it) }.orEmpty(),
                                        statusExplanation = if (httpCode == null) {
                                            mpvNonHttpExplanationText(fileError, logLine)
                                        } else {
                                            ""
                                        },
                                    ),
                                )
                            }
                        }
                    }
                }
            }
        }
        val logObserver = object : MPV.LogObserver {
            override fun logMessage(prefix: String, level: Int, text: String) {
                if (prefix == "af" || prefix == "lavfi" || prefix.startsWith("af/") || text.contains("acompressor")) {
                    InAppLogger.warn("Player/NightMode", "mpv $prefix: ${text.trim()}")
                }
                Log.w(
                    PLAYER_DIAGNOSTIC_TAG,
                    "mpv_log level=$level prefix=${diagnosticPlayerMessage(prefix)} " +
                        "message=${diagnosticPlayerMessage(text)}",
                )
                errorLog.onLog(prefix, level, text)
            }
        }
        view.mpv.addObserver(observer)
        view.mpv.addLogObserver(logObserver)
        onDispose {
            view.mpv.removeObserver(observer)
            view.mpv.removeLogObserver(logObserver)
        }
    }

    DisposableEffect(playerViewRef) {
        val view = playerViewRef ?: return@DisposableEffect onDispose {}
        PlayerPictureInPictureManager.registerPausePlaybackCallback {
            view.setPaused(true)
        }
        onDispose {
            PlayerPictureInPictureManager.registerPausePlaybackCallback(null)
            view.keepScreenOn = false
        }
    }

    LaunchedEffect(playerViewRef, sourceUrl, sourceAudioUrl, sanitizedSourceHeaders, externalSubtitles) {
        val view = playerViewRef ?: return@LaunchedEffect
        playbackDiagnostics.attempt += 1
        playbackDiagnostics.prepareStartedAtMs = SystemClock.elapsedRealtime()
        Log.i(
            PLAYER_DIAGNOSTIC_TAG,
            "mpv_prepare_begin attempt=${playbackDiagnostics.attempt} " +
                "source=${diagnosticPlaybackSource(sourceUrl)} audioSource=${!sourceAudioUrl.isNullOrBlank()}",
        )
        val snapshot = PlayerPlaybackSnapshot()
        latestOnSnapshot.value(snapshot)
        nowPlayingController?.syncPlayback(snapshot)
        view.loadSource(
            sourceUrl = sourceUrl,
            sourceAudioUrl = sourceAudioUrl,
            requestHeaders = sanitizedSourceHeaders,
            externalSubtitles = externalSubtitles,
            playWhenReady = latestPlayWhenReady.value,
        )
    }

    val liveAnimeSettings by rememberAnimeToggles()
    LaunchedEffect(
        playerViewRef,
        animeContent,
        liveAnimeSettings.androidAnimeUpscaleEnabled,
        liveAnimeSettings.androidAnimeLineSharpenEnabled,
    ) {
        val view = playerViewRef ?: return@LaunchedEffect
        val paths = AnimeShaders.mpvShaderPaths(
            context = context,
            upscaleEnabled = animeContent && liveAnimeSettings.androidAnimeUpscaleEnabled,
            lineSharpenEnabled = animeContent && liveAnimeSettings.androidAnimeLineSharpenEnabled,
        )
        view.setAnimeShaderPaths(paths)
    }

    LaunchedEffect(playerViewRef, playWhenReady) {
        val view = playerViewRef ?: return@LaunchedEffect
        view.setPaused(!latestPlayWhenReady.value)
        val snapshot = view.snapshot()
        view.keepScreenOn = snapshot.isPlaying || snapshot.isLoading
        latestOnSnapshot.value(snapshot)
        nowPlayingController?.syncPlayback(snapshot)
    }

    LaunchedEffect(playerViewRef, resizeMode) {
        playerViewRef?.applyResizeMode(resizeMode)
    }

    LaunchedEffect(playerViewRef) {
        val view = playerViewRef ?: return@LaunchedEffect
        PlayerSettingsRepository.uiState
            .map { it.nightModeActive }
            .distinctUntilChanged()
            .collect { view.applyNightMode(it) }
    }

    LaunchedEffect(playerViewRef, sourceUrl, sourceAudioUrl, sanitizedSourceHeaders, externalSubtitles) {
        val view = playerViewRef ?: return@LaunchedEffect
        onControllerReady(
            autoSyncCoordinator.wrap( // AutoSync hook
                view.controller(context, nowPlayingController),
                view::replaceExternalSubtitle,
            ),
        )
    }

    LaunchedEffect(playerViewRef) {
        val view = playerViewRef ?: return@LaunchedEffect
        while (isActive) {
            val snapshot = view.snapshot()
            latestOnSnapshot.value(snapshot)
            nowPlayingController?.syncPlayback(snapshot)
            view.keepScreenOn = snapshot.isPlaying || snapshot.isLoading
            delay(250L)
        }
    }

    Box(modifier = modifier) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { viewContext ->
                NuvioLibmpvView(
                    context = viewContext,
                    videoOutput = videoOutput,
                    hardwareDecodingEnabled = hardwareDecodingEnabled,
                    yuv420pEnabled = yuv420pEnabled,
                    animeShaderPaths = AnimeShaders.mpvShaderPaths(
                        context = viewContext,
                        upscaleEnabled = animeUpscaleEnabled,
                        lineSharpenEnabled = animeLineSharpenEnabled,
                    ),
                ).apply {
                    layoutParams = android.view.ViewGroup.LayoutParams(MATCH_PARENT, MATCH_PARENT)
                    keepScreenOn = false
                    runCatching {
                        Utils.copyAssets(viewContext)
                        initialize(viewContext.filesDir.path, viewContext.cacheDir.path)
                    }.onFailure { error ->
                        Log.e(TAG, "Failed to initialize libmpv", error)
                        InAppLogger.error("MPV/Android", "Failed to initialize libmpv: ${error.localizedMessage ?: error::class.simpleName.orEmpty()}")
                        latestOnError.value(error.localizedMessage ?: "libmpv unavailable")
                    }
                    playerViewRef = this
                }
            },
            update = { view ->
                playerViewRef = view
                view.applyResizeMode(resizeMode)
            },
            onRelease = { view ->
                if (playerViewRef === view) playerViewRef = null
                view.releaseMpv()
            },
        )
        playerViewRef?.let { view ->
            StyledSubtitleOverlay(
                view.subtitleText,
                view.subtitleStyle,
                videoAspectRatio = view.subtitleVideoAspectRatio,
                videoResizeMode = resizeMode,
            )
        }
    }
}

private tailrec fun Context.findActivity(): Activity? =
    when (this) {
        is Activity -> this
        is ContextWrapper -> baseContext.findActivity()
        else -> null
    }

private class NuvioLibmpvView(
    context: Context,
    private val videoOutput: AndroidLibmpvVideoOutput,
    private val hardwareDecodingEnabled: Boolean,
    private val yuv420pEnabled: Boolean,
    private val animeShaderPaths: List<String>,
) : MpvSurfaceView(context, videoOutput.mpvValue) {
    @Volatile
    private var activeAnimeShaderPaths = animeShaderPaths

    fun setAnimeShaderPaths(paths: List<String>) {
        if (paths == activeAnimeShaderPaths) return
        activeAnimeShaderPaths = paths
        InAppLogger.info(
            "MPV/Android",
            "anime shaders updated live: ${paths.joinToString(",") { it.substringAfterLast('/') }.ifEmpty { "none" }}",
        )
        executeMpv {
            mpv.setPropertyString("glsl-shaders", paths.joinToString(":"))
        }
    }
    private var currentSourceUrl: String? = null
    private var currentSourceAudioUrl: String? = null
    private var currentRequestHeaders: Map<String, String> = emptyMap()
    private var currentExternalSubtitles: List<com.nuvio.app.features.streams.StreamSubtitle> = emptyList()
    @Volatile
    private var latestSnapshot = PlayerPlaybackSnapshot()

    val subtitleVideoAspectRatio: Float
        get() = latestSnapshot.let { snapshot ->
            if (snapshot.videoWidth > 0 && snapshot.videoHeight > 0) {
                snapshot.videoWidth.toFloat() / snapshot.videoHeight.toFloat()
            } else {
                0f
            }
        }

    @Volatile
    private var libmpvVolumeLevel = 1f
    @Volatile
    private var latestAudioTracks: List<LibmpvTrack> = emptyList()
    @Volatile
    private var latestSubtitleTracks: List<LibmpvTrack> = emptyList()

    var subtitleText by mutableStateOf("")
        private set
    var subtitleStyle by mutableStateOf(SubtitleStyleState.DEFAULT)
        private set
    private var appliedSubtitleStyle = SubtitleStyleState.DEFAULT
    private var styledSubtitleVisible = false

    fun updateStyledSubtitle() {
        executeMpv {
            val styled = appliedSubtitleStyle.requiresComposeStyledOverlay &&
                SubtitleRendering.supportsTextOverlay(
                    mpv.getPropertyString("current-tracks/sub/codec").orEmpty(),
                )
            if (styled != styledSubtitleVisible) {
                mpv.setPropertyBoolean("sub-visibility", !styled)
                styledSubtitleVisible = styled
            }
            val text = if (styled) mpv.getPropertyString("sub-text").orEmpty() else ""
            val style = appliedSubtitleStyle
            post {
                if (!released.get()) {
                    subtitleText = text
                    subtitleStyle = style
                }
            }
        }
    }

    override fun initOptions() {
        InAppLogger.info(
            "MPV/Android",
            "Initializing libmpv vo=${videoOutput.mpvValue} hwdec=${if (hardwareDecodingEnabled) "auto" else "no"} yuv420p=$yuv420pEnabled " +
                "animeShaders=${animeShaderPaths.joinToString(",") { it.substringAfterLast('/') }.ifEmpty { "none" }}",
        )
        mpv.setOptionString("profile", "fast")
        mpv.setOptionString("hwdec", if (hardwareDecodingEnabled) "auto" else "no")
        if (yuv420pEnabled) {
            mpv.setOptionString("vf", "format=yuv420p")
        }
        mpv.setOptionString("msg-level", "all=warn")
        // Android has no youtube-dl, so mpv's fallback to it can only fail and bury the real error.
        mpv.setOptionString("ytdl", "no").logIfMpvError("ytdl")
        mpv.setOptionString("tls-verify", "yes")
        mpv.setOptionString("tls-ca-file", "${context.filesDir.path}/cacert.pem")
        mpv.setOptionString("demuxer-lavf-o", "protocol_whitelist=[file,crypto,data,http,https,tcp,tls]").logIfMpvError("demuxer-lavf-o")
        mpv.setOptionString("demuxer-max-bytes", "${libmpvCacheBytes()}").logIfMpvError("demuxer-max-bytes")
        mpv.setOptionString("demuxer-max-back-bytes", "${libmpvCacheBytes()}").logIfMpvError("demuxer-max-back-bytes")
        // Room above 100% for the player's amplification (+10 dB is about 316%).
        mpv.setOptionString("volume-max", "$LIBMPV_MAX_VOLUME_PERCENT").logIfMpvError("volume-max")
        mpv.setOptionString("vd-lavc-film-grain", "cpu")
        if (animeShaderPaths.isNotEmpty()) {
            mpv.setOptionString("glsl-shaders", animeShaderPaths.joinToString(":")).logIfMpvError("glsl-shaders")
        }
        mpv.setPropertyBoolean("keep-open", true)
        mpv.setPropertyBoolean("input-default-bindings", true)
        mpv.setPropertyBoolean("audio-fallback-to-null", true)
    }

    override fun observeProperties() {
        val props = mapOf(
            "pause" to MPV.mpvFormat.MPV_FORMAT_FLAG,
            "paused-for-cache" to MPV.mpvFormat.MPV_FORMAT_FLAG,
            "core-idle" to MPV.mpvFormat.MPV_FORMAT_FLAG,
            "eof-reached" to MPV.mpvFormat.MPV_FORMAT_FLAG,
            "seeking" to MPV.mpvFormat.MPV_FORMAT_FLAG,
            "cache-buffering-state" to MPV.mpvFormat.MPV_FORMAT_INT64,
            "duration" to MPV.mpvFormat.MPV_FORMAT_DOUBLE,
            "time-pos" to MPV.mpvFormat.MPV_FORMAT_DOUBLE,
            "demuxer-cache-time" to MPV.mpvFormat.MPV_FORMAT_DOUBLE,
            "speed" to MPV.mpvFormat.MPV_FORMAT_DOUBLE,
            "video-params/w" to MPV.mpvFormat.MPV_FORMAT_INT64,
            "video-params/h" to MPV.mpvFormat.MPV_FORMAT_INT64,
            "video-out-params/w" to MPV.mpvFormat.MPV_FORMAT_INT64,
            "video-out-params/h" to MPV.mpvFormat.MPV_FORMAT_INT64,
            "track-list" to MPV.mpvFormat.MPV_FORMAT_NODE,
            "video-codec" to MPV.mpvFormat.MPV_FORMAT_STRING,
            "audio-codec" to MPV.mpvFormat.MPV_FORMAT_STRING,
            "hwdec-current" to MPV.mpvFormat.MPV_FORMAT_STRING,
            "video-params" to MPV.mpvFormat.MPV_FORMAT_NODE,
            "audio-params" to MPV.mpvFormat.MPV_FORMAT_NODE,
            "sid" to MPV.mpvFormat.MPV_FORMAT_INT64,
            "sub-text" to MPV.mpvFormat.MPV_FORMAT_STRING,
        )
        props.forEach { (name, format) -> mpv.observeProperty(name, format) }
    }

    suspend fun loadSource(
        sourceUrl: String,
        sourceAudioUrl: String?,
        requestHeaders: Map<String, String>,
        externalSubtitles: List<com.nuvio.app.features.streams.StreamSubtitle>,
        playWhenReady: Boolean,
    ) {
        surfaceReady.await()
        withContext(mpvDispatcher) {
            if (!released.get()) {
                val sameSource =
                    currentSourceUrl == sourceUrl &&
                        currentSourceAudioUrl == sourceAudioUrl &&
                        currentRequestHeaders == requestHeaders &&
                        currentExternalSubtitles == externalSubtitles
                currentSourceUrl = sourceUrl
                currentSourceAudioUrl = sourceAudioUrl
                currentRequestHeaders = requestHeaders
                currentExternalSubtitles = externalSubtitles
                if (!sameSource) {
                    InAppLogger.info(
                        "MPV/Android",
                        "loadfile url=${sourceUrl.redactedPlaybackUrlForLogs()} audio=${!sourceAudioUrl.isNullOrBlank()} subtitles=${externalSubtitles.size} playWhenReady=$playWhenReady",
                    )
                    loadCurrentSourceNow(playWhenReady = playWhenReady)
                } else {
                    applyRequestHeadersNow(requestHeaders)
                    setPausedNow(!playWhenReady)
                }
            }
        }
    }

    private fun loadCurrentSourceNow(playWhenReady: Boolean) {
        val sourceUrl = currentSourceUrl ?: return
        applyRequestHeadersNow(currentRequestHeaders)
        setPausedNow(!playWhenReady)
        mpv.setPropertyString("aid", "auto")
        mpv.command("loadfile", sourceUrl.toMpvSource(), "replace")
        currentSourceAudioUrl?.takeIf { it.isNotBlank() }?.let { sourceAudioUrl ->
            mpv.command("audio-add", sourceAudioUrl.toMpvSource(), "auto")
        }
        setPausedNow(!playWhenReady)
    }

    fun attachStartupSubtitles() {
        executeMpv {
            currentExternalSubtitles.forEachIndexed { index, subtitle ->
                val flag = if (index == 0) "auto" else "cached"
                mpv.command("sub-add", subtitle.url.toMpvSource(), flag, subtitle.name ?: subtitle.language, subtitle.language)
            }
        }
    }

    private fun String.toMpvSource(): String =
        if (!startsWith("file:", ignoreCase = true)) {
            this
        } else {
            runCatching { File(URI(this)).absolutePath }.getOrDefault(this)
        }

    fun setPaused(paused: Boolean) {
        executeMpv { setPausedNow(paused) }
    }

    fun seekToMs(positionMs: Long) {
        executeMpv {
            mpv.command("seek", (positionMs.coerceAtLeast(0L) / 1000.0).toString(), "absolute")
        }
    }

    /** mpv lists the chapters of the loaded file itself. */
    suspend fun readChapters(): List<PlayerChapter> {
        if (released.get()) return emptyList()
        return runCatching {
            withContext(mpvDispatcher) {
                if (released.get()) return@withContext emptyList()
                val count = mpv.getPropertyInt("chapter-list/count") ?: 0
                (0 until count).mapNotNull { i ->
                    val seconds = mpv.getPropertyDouble("chapter-list/$i/time") ?: return@mapNotNull null
                    PlayerChapter(
                        startMs = (seconds * 1000.0).toLong(),
                        title = mpv.getPropertyString("chapter-list/$i/title")?.trim()?.takeIf { it.isNotBlank() },
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    suspend fun snapshot(): PlayerPlaybackSnapshot {
        if (released.get()) return latestSnapshot
        return withContext(mpvDispatcher) {
            if (released.get()) {
                latestSnapshot
            } else {
                runCatching { readSnapshotNow() }
                    .onSuccess { latestSnapshot = it }
                    .getOrDefault(latestSnapshot)
            }
        }
    }

    suspend fun mediaInfo(): PlayerMediaInfo {
        if (released.get()) return PlayerMediaInfo()
        return withContext(mpvDispatcher) {
            if (released.get()) {
                PlayerMediaInfo()
            } else {
                runCatching { mpvMediaInfo(mpv::getPropertyString) }.getOrDefault(PlayerMediaInfo())
            }
        }
    }

    @Volatile
    private var cacheSpeedBytesPerSecond: Long? = null

    private var cachedChapters: List<PlayerChapter> = emptyList()
    private var cachedChaptersKey: String? = null

    private fun readSnapshotNow(): PlayerPlaybackSnapshot {
        val paused = mpv.getPropertyBoolean("pause") ?: true
        val pausedForCache = mpv.getPropertyBoolean("paused-for-cache") ?: false
        val idle = mpv.getPropertyBoolean("core-idle") ?: false
        val ended = mpv.getPropertyBoolean("eof-reached") ?: false
        val seeking = mpv.getPropertyBoolean("seeking") ?: false
        val cacheBufferingState = mpv.getPropertyInt("cache-buffering-state")
        cacheSpeedBytesPerSecond = mpv.getPropertyInt("cache-speed")
            ?.takeIf { it >= 0 }
            ?.toLong()
        val durationMs = mpv.getPropertyDouble("duration").toMillis()
        val positionMs = mpv.getPropertyDouble("time-pos")
            ?.let { timePos ->
                mpvPlaybackPositionSec(
                    timePosSec = timePos,
                    audioPtsSec = mpv.getPropertyDouble("audio-pts"),
                    seeking = seeking,
                    audioDelaySec = mpv.getPropertyDouble("audio-delay") ?: 0.0,
                )
            }
            .toMillis()
        val cachePositionMs = mpv.getPropertyDouble("demuxer-cache-time").toMillis()
        val isCacheBuffering = cacheBufferingState != null && cacheBufferingState in 0 until 100
        val isLoading = pausedForCache ||
            (!paused && !ended && (seeking || isCacheBuffering || (idle && durationMs <= 0L)))
        val videoWidth = mpv.getPropertyInt("video-out-params/dw")
            ?: mpv.getPropertyInt("video-params/dw")
            ?: 0
        val videoHeight = mpv.getPropertyInt("video-out-params/dh")
            ?: mpv.getPropertyInt("video-params/dh")
            ?: 0
        return PlayerPlaybackSnapshot(
            isLoading = isLoading,
            isPlaying = !paused && !isLoading && !idle && !ended,
            isEnded = ended,
            durationMs = durationMs,
            positionMs = positionMs,
            bufferedPositionMs = maxOf(positionMs, cachePositionMs),
            playbackSpeed = (mpv.getPropertyDouble("speed") ?: 1.0).toFloat(),
            videoWidth = videoWidth,
            videoHeight = videoHeight,
            mediaInfoJson = buildLibmpvMediaInfoJson(),
            chapters = chaptersFor(durationMs),
            animeEnhancement = AnimeShaders.mpvStatus(
                context = context,
                shaderPaths = activeAnimeShaderPaths,
                videoWidth = mpv.getPropertyInt("video-params/w") ?: 0,
                videoHeight = mpv.getPropertyInt("video-params/h") ?: 0,
                outputWidth = mpv.getPropertyInt("osd-width") ?: width,
                outputHeight = mpv.getPropertyInt("osd-height") ?: height,
            ),
        )
    }

    private fun chaptersFor(durationMs: Long): List<PlayerChapter> {
        if (durationMs <= 0L) return emptyList()
        val key = "$currentSourceUrl|$durationMs"
        if (key != cachedChaptersKey) {
            cachedChaptersKey = key
            cachedChapters = runCatching { PlayerChapters.normalize(mpvChapters(mpv::getPropertyString)) }.getOrDefault(emptyList())
        }
        return cachedChapters
    }


    private fun buildLibmpvMediaInfoJson(): String {
        return try {
            val nodes = mpv.getPropertyNode("track-list")?.asArray()?.toList().orEmpty()
            var videoCodec = mpv.getPropertyString("video-codec").orEmpty()
            var videoDecoder = ""
            var dvProfile = ""
            var codecProfile = ""
            val filename = currentSourceUrl?.substringBefore('?')?.substringAfterLast('/').orEmpty()
            val gamma = mpv.getPropertyString("video-params/gamma").orEmpty()
            val primaries = mpv.getPropertyString("video-params/primaries").orEmpty()
            val colorLevels = mpv.getPropertyString("video-params/colorlevels").orEmpty()
            val pixelFormat = mpv.getPropertyString("video-out-params/pixelformat").orEmpty()
            val videoWidth = mpv.getPropertyInt("video-params/w") ?: 0
            val videoHeight = mpv.getPropertyInt("video-params/h") ?: 0
            val fps = mpv.getPropertyDouble("container-fps") ?: 0.0
            val hwdecCurrent = mpv.getPropertyString("hwdec-current").orEmpty()
            var hdrFormat = ""

            for (node in nodes) {
                if (node.nodeString("type") == "video" && node.nodeBoolean("selected") != false) {
                    videoCodec = node.nodeString("codec") ?: videoCodec
                    videoDecoder = node.nodeString("decoder-desc").orEmpty()
                    dvProfile = node.nodeString("dolby-vision-profile")
                        ?: node.nodeString("dv_profile")
                        ?: ""
                    codecProfile = node.nodeString("codec-profile").orEmpty()
                    val dvLower = dvProfile.lowercase()
                    val isDolbyVision = dvProfile.isNotBlank() &&
                        dvLower != "none" &&
                        dvLower != "unknown" &&
                        dvLower != "0" &&
                        dvLower != "false"
                    if (
                        isDolbyVision ||
                        videoCodec.contains("dovi", ignoreCase = true) ||
                        videoCodec.contains("dvhe", ignoreCase = true) ||
                        videoCodec.contains("dvh1", ignoreCase = true) ||
                        videoDecoder.contains("dovi", ignoreCase = true) ||
                        codecProfile.contains("dovi", ignoreCase = true)
                    ) {
                        hdrFormat = "dolby_vision"
                    }
                    break
                }
            }

            if (hdrFormat.isEmpty()) {
                hdrFormat = when {
                    gamma.equals("hlg", ignoreCase = true) -> "hlg"
                    gamma.equals("pq", ignoreCase = true) -> "hdr"
                    primaries.equals("bt.2020", ignoreCase = true) ||
                        primaries.equals("bt.2020nc", ignoreCase = true) -> "hdr"
                    gamma.equals("sdr", ignoreCase = true) -> "sdr"
                    else -> ""
                }
            }

            var audioCodec = mpv.getPropertyString("audio-codec").orEmpty()
            var audioDecoder = ""
            var audioChannels = ""
            var audioSampleRate = ""
            var audioLang = ""
            for (node in nodes) {
                if (node.nodeString("type") == "audio" && node.nodeBoolean("selected") == true) {
                    audioCodec = node.nodeString("codec") ?: audioCodec
                    audioDecoder = node.nodeString("decoder-desc").orEmpty()
                    val channelCount = node.nodeInt("demux-channel-count") ?: 0
                    audioChannels = if (channelCount > 0) channelCount.toString() else ""
                    val sampleRate = node.nodeInt("demux-samplerate") ?: 0
                    audioSampleRate = if (sampleRate > 0) sampleRate.toString() else ""
                    audioLang = node.nodeString("lang").orEmpty()
                    break
                }
            }

            val videoBitrate = mpv.getPropertyDouble("video-bitrate") ?: 0.0
            val audioBitrate = mpv.getPropertyDouble("audio-bitrate") ?: 0.0
            val videoBitrateKbps = if (videoBitrate.isFinite() && videoBitrate > 0) (videoBitrate / 1000.0).toInt() else 0
            val audioBitrateKbps = if (audioBitrate.isFinite() && audioBitrate > 0) (audioBitrate / 1000.0).toInt() else 0

            buildString {
                append('{')
                appendJsonString("engine", "libmpv")
                append(',')
                appendJsonString("filename", filename)
                append(',')
                appendJsonString("videoCodec", videoCodec)
                append(',')
                appendJsonString("videoDecoder", videoDecoder)
                append(',')
                appendJsonString("dvProfile", dvProfile)
                append(',')
                appendJsonString("codecProfile", codecProfile)
                append(',')
                appendJsonString("hdrFormat", hdrFormat)
                append(',')
                appendJsonString("gamma", gamma)
                append(',')
                appendJsonString("primaries", primaries)
                append(',')
                appendJsonString("colorLevels", colorLevels)
                append(',')
                appendJsonString("pixelFormat", pixelFormat)
                append(',')
                append("\"videoWidth\":").append(videoWidth).append(',')
                append("\"videoHeight\":").append(videoHeight).append(',')
                append("\"fps\":").append(if (fps.isFinite()) fps else 0.0).append(',')
                appendJsonString("hwdecCurrent", hwdecCurrent)
                append(',')
                appendJsonString("audioCodec", audioCodec)
                append(',')
                appendJsonString("audioDecoder", audioDecoder)
                append(',')
                appendJsonString("audioChannels", audioChannels)
                append(',')
                appendJsonString("audioSampleRate", audioSampleRate)
                append(',')
                appendJsonString("audioLang", audioLang)
                append(',')
                append("\"videoBitrateKbps\":").append(videoBitrateKbps).append(',')
                append("\"audioBitrateKbps\":").append(audioBitrateKbps)
                append('}')
            }
        } catch (error: Throwable) {
            InAppLogger.warn("MPV/Android", "Failed to build playback info: ${InAppLogger.throwableSummary(error)}")
            "{}"
        }
    }

    suspend fun playbackDiagnosticsForLogs(): String {
        if (released.get()) return "released"
        return withContext(mpvDispatcher) {
            if (released.get()) {
                "released"
            } else {
                runCatching {
                    buildString {
                        append("videoCodec=")
                        append(mpv.getPropertyString("video-codec") ?: "unknown")
                        append(" audioCodec=")
                        append(mpv.getPropertyString("audio-codec") ?: "unknown")
                        append(" hwdec=")
                        append(mpv.getPropertyString("hwdec-current") ?: "unknown")
                        append(" videoParams=")
                        append(mpv.getPropertyNode("video-params")?.toMpvNodeSummary() ?: "unknown")
                        append(" audioParams=")
                        append(mpv.getPropertyNode("audio-params")?.toMpvNodeSummary() ?: "unknown")
                    }
                }.getOrDefault("unavailable")
            }
        }
    }

    fun applyNightMode(enabled: Boolean) {
        executeMpv {
            runCatching { mpv.command("af", "remove", PlayerNightMode.MPV_FILTER_LABEL) }
            if (enabled) {
                mpv.command("af", "add", PlayerNightMode.MPV_FILTER)
            }
            val chain = runCatching { mpv.getPropertyString("af") }.getOrNull()
            InAppLogger.info("Player/NightMode", "libmpv night mode ${if (enabled) "on" else "off"} af=$chain")
            if (enabled && chain?.contains(PlayerNightMode.MPV_FILTER_LABEL) != true) {
                InAppLogger.warn("Player/NightMode", "libmpv did not keep the night mode filter; acompressor may be missing from its FFmpeg build")
            }
        }
    }

    fun applyResizeMode(resizeMode: PlayerResizeMode) {
        executeMpv {
            when (resizeMode) {
                PlayerResizeMode.Fit -> {
                    mpv.setPropertyString("keepaspect", "yes")
                    mpv.setPropertyDouble("panscan", 0.0)
                    mpv.setPropertyString("video-aspect-override", "no")
                }
                PlayerResizeMode.Fill -> {
                    mpv.setPropertyString("keepaspect", "no")
                    mpv.setPropertyDouble("panscan", 0.0)
                    mpv.setPropertyString("video-aspect-override", "no")
                }
                PlayerResizeMode.Zoom -> {
                    mpv.setPropertyString("keepaspect", "yes")
                    mpv.setPropertyDouble("panscan", 1.0)
                    mpv.setPropertyString("video-aspect-override", "no")
                }
            }
        }
    }

    fun seekByMs(offsetMs: Long) {
        executeMpv {
            mpv.command("seek", (offsetMs / 1000.0).toString(), "relative")
        }
    }

    fun controller(
        context: Context,
        nowPlayingController: AndroidPlayerNowPlayingController?,
    ): PlayerEngineController =
        object : PlayerEngineController {
            override val playbackEngine = AndroidPlaybackEngine.Libmpv

            override fun networkSpeedBytesPerSecond(): Long? = cacheSpeedBytesPerSecond

            private var lastAppliedVolume: Float? = null
            private var lastLoggedAudioTracks: String? = null
            private var lastLoggedSubtitleTracks: String? = null

            override fun play() {
                InAppLogger.debug("MPV/Android", "control play positionMs=${latestSnapshot.positionMs}")
                setPaused(false)
            }

            override fun pause() {
                InAppLogger.debug("MPV/Android", "control pause positionMs=${latestSnapshot.positionMs}")
                setPaused(true)
            }

            override fun seekTo(positionMs: Long) {
                val targetMs = positionMs.coerceAtLeast(0L)
                InAppLogger.info("MPV/Android", "control seekTo targetMs=$targetMs")
                this@NuvioLibmpvView.seekToMs(targetMs)
            }

            override fun seekBy(offsetMs: Long) {
                InAppLogger.info("MPV/Android", "control seekBy offsetMs=$offsetMs")
                this@NuvioLibmpvView.seekByMs(offsetMs)
            }

            override suspend fun getChapters(): List<PlayerChapter> = this@NuvioLibmpvView.readChapters()

            override fun retry() {
                InAppLogger.info("MPV/Android", "control retry url=${InAppLogger.redactUrl(currentSourceUrl)}")
                executeMpv { loadCurrentSourceNow(playWhenReady = true) }
            }

            override suspend fun getMediaInfo(): PlayerMediaInfo = mediaInfo()

            override fun setPlaybackSpeed(speed: Float) {
                val target = speed.coerceIn(0.25f, 4f)
                InAppLogger.info("MPV/Android", "control speed=$target")
                executeMpv { mpv.setPropertyDouble("speed", target.toDouble()) }
            }

            override fun setVideoZoom(scale: Float) {
                val zoom = kotlin.math.ln(scale.coerceIn(0.25f, 4f).toDouble()) / kotlin.math.ln(2.0)
                executeMpv { mpv.setPropertyDouble("video-zoom", zoom) }
            }

            override fun updateNowPlayingMetadata(info: PlayerNowPlayingInfo) {
                nowPlayingController?.updateMetadata(info)
            }

            override fun clearNowPlayingInfo() {
                nowPlayingController?.clear()
            }

            override fun setMuted(muted: Boolean) {
                InAppLogger.debug("MPV/Android", "control muted=$muted")
                executeMpv { mpv.setPropertyBoolean("mute", muted) }
            }

            override fun currentPlayerVolume(): PlayerAudioLevel = PlayerAudioLevel(
                fraction = libmpvVolumeLevel,
                isMuted = libmpvVolumeLevel <= 0.001f,
            )

            override fun setPlayerVolume(level: Float): PlayerAudioLevel {
                val target = level.coerceIn(0f, 2f)
                libmpvVolumeLevel = target
                if (target != lastAppliedVolume) {
                    lastAppliedVolume = target
                    val mpvVolume = (100.0 * playerBoostLinearGain(target).toDouble().pow(1.0 / 3.0))
                        .coerceIn(0.0, LIBMPV_VOLUME_MAX.toDouble())
                    executeMpv { mpv.setPropertyDouble("volume", mpvVolume) }
                }
                return PlayerAudioLevel(
                    fraction = target,
                    isMuted = target <= 0.001f,
                )
            }

            override fun getAudioTracks(): List<AudioTrack> {
                val tracks = latestAudioTracks.mapIndexed { index, track ->
                    AudioTrack(
                        index = index,
                        id = track.id.toString(),
                        label = track.label,
                        language = track.language,
                        isSelected = track.isSelected,
                    )
                }
                val tracksLog =
                    "getAudioTracks count=${tracks.size} selected=${tracks.firstOrNull { it.isSelected }?.index ?: -1}"
                if (tracksLog != lastLoggedAudioTracks) {
                    lastLoggedAudioTracks = tracksLog
                    InAppLogger.debug("MPV/Android", tracksLog)
                }
                return tracks
            }

            override fun getSubtitleTracks(): List<SubtitleTrack> {
                val tracks = latestSubtitleTracks.mapIndexed { index, track ->
                    SubtitleTrack(
                        index = index,
                        id = track.id.toString(),
                        label = track.label,
                        language = track.language,
                        isSelected = track.isSelected,
                        isForced = track.isForced,
                    )
                }
                val tracksLog =
                    "getSubtitleTracks count=${tracks.size} selected=${tracks.firstOrNull { it.isSelected }?.index ?: -1}"
                if (tracksLog != lastLoggedSubtitleTracks) {
                    lastLoggedSubtitleTracks = tracksLog
                    InAppLogger.debug("MPV/Android", tracksLog)
                }
                return tracks
            }

            override fun selectAudioTrack(index: Int) {
                InAppLogger.info("MPV/Android", "select audio track index=$index")
                if (index < 0) {
                    executeMpv { mpv.setPropertyString("aid", "no") }
                } else {
                    latestAudioTracks.getOrNull(index)?.let { track ->
                        InAppLogger.debug("MPV/Android", "select audio track mpvId=${track.id} label=${track.label}")
                        executeMpv { mpv.setPropertyInt("aid", track.id) }
                    }
                }
            }

            override fun applyAudioLanguagePreferences(languages: List<String>) {
                executeMpv {
                    mpv.setPropertyString("alang", languages.joinToString(","))
                    mpv.getPropertyString("aid")?.takeIf { it.toIntOrNull() != null }?.let { currentId ->
                        mpv.setPropertyString("aid", currentId)
                    }
                    mpv.setPropertyString("aid", "auto")
                }
            }

            override fun selectSubtitleTrack(index: Int) {
                InAppLogger.info("MPV/Android", "select subtitle track index=$index")
                if (index < 0) {
                    executeMpv { mpv.setPropertyString("sid", "no") }
                } else {
                    latestSubtitleTracks.getOrNull(index)?.let { track ->
                        InAppLogger.debug("MPV/Android", "select subtitle track mpvId=${track.id} label=${track.label}")
                        executeMpv { mpv.setPropertyInt("sid", track.id) }
                    }
                }
            }

            override fun setSubtitleUri(url: String) {
                InAppLogger.info("MPV/Android", "set external subtitle url=${InAppLogger.redactUrl(url)}")
                executeMpv { mpv.command("sub-add", url, "select") }
            }

            override fun clearExternalSubtitle() {
                InAppLogger.info("MPV/Android", "clear external subtitle")
                executeMpv { mpv.setPropertyString("sid", "no") }
            }

            override fun clearExternalSubtitleAndSelect(trackIndex: Int) {
                InAppLogger.info("MPV/Android", "clear external subtitle and select builtInIndex=$trackIndex")
                selectSubtitleTrack(trackIndex)
            }

            override fun applySubtitlePreferences(
                preferredLanguage: String,
                secondaryPreferredLanguage: String?,
                useForcedSubtitles: Boolean,
                autoSelectionApplied: Boolean,
                hasActiveSubtitle: Boolean,
                useCustomSubtitles: Boolean,
            ) {
                if ((hasActiveSubtitle || useCustomSubtitles) && autoSelectionApplied) {
                    return
                }
                val languages = listOfNotNull(
                    preferredLanguage.takeIf { language ->
                        language.isNotBlank() &&
                            !language.equals(SubtitleLanguageOption.NONE, ignoreCase = true) &&
                            !language.equals(SubtitleLanguageOption.FORCED, ignoreCase = true)
                    },
                    secondaryPreferredLanguage?.takeIf { language ->
                        language.isNotBlank() &&
                            !language.equals(SubtitleLanguageOption.NONE, ignoreCase = true) &&
                            !language.equals(SubtitleLanguageOption.FORCED, ignoreCase = true)
                    },
                )
                executeMpv {
                    if (languages.isEmpty()) {
                        mpv.setPropertyString("sid", "no")
                    } else {
                        mpv.setPropertyString("slang", languages.joinToString(","))
                    }
                }
            }

            override fun applySubtitleStyle(style: SubtitleStyleState) {
                InAppLogger.debug(
                    "MPV/Android",
                    "apply subtitle style font=${style.fontSizeSp} bold=${style.bold} outline=${style.outlineEnabled}:${style.outlineWidth} bottom=${style.bottomOffset}",
                )
                executeMpv {
                    appliedSubtitleStyle = style
                    mpv.setPropertyString("sub-ass-override", "no")
                    mpv.setPropertyString("sub-color", style.textColor.toMpvColor())
                    mpv.setPropertyString("sub-back-color", style.backgroundColor.toMpvColor())
                    val nativeOutlineColor = style.outlineColor.copy(
                        alpha = style.outlineColor.alpha * style.textColor.alpha *
                            subtitleOutlineBlurOpacity(style.mpvNativeOutlineBlurLevel),
                    )
                    mpv.setPropertyString("sub-outline-color", nativeOutlineColor.toMpvColor())
                    mpv.setPropertyString("sub-border-color", nativeOutlineColor.toMpvColor())
                    mpv.setPropertyString("sub-border-style", style.toMpvSubtitleBorderStyle())
                    mpv.setPropertyString("sub-bold", if (style.bold) "yes" else "no")
                    mpv.setPropertyInt("sub-font-size", style.toMpvSubtitleFontSize())
                    mpv.setPropertyInt("sub-outline-size", style.toMpvSubtitleOutlineSize())
                    mpv.setPropertyInt("sub-border-size", style.toMpvSubtitleOutlineSize())
                    // Boost low blur levels so they soften the border instead of only thickening it.
                    mpv.setPropertyString("sub-blur", style.mpvNativeOutlineBlurAmount.toString())
                    mpv.setPropertyInt("sub-pos", (100 - style.bottomOffset / 10).coerceIn(0, 100))
                    mpv.setPropertyBoolean("sub-filter-sdh", style.stripSdh)
                    mpv.setPropertyBoolean("sub-filter-sdh-harder", style.stripSdh)
                    updateStyledSubtitle()
                }
            }

            override fun setSubtitleDelayMs(delayMs: Int) {
                val targetMs = delayMs.coerceIn(SUBTITLE_DELAY_MIN_MS, SUBTITLE_DELAY_MAX_MS)
                InAppLogger.info("MPV/Android", "set subtitle delay ms=$targetMs")
                executeMpv {
                    mpv.setPropertyDouble("sub-delay", targetMs / 1000.0)
                }
            }

            override val supportsAudioDelay = true

            override fun setAudioDelayMs(delayMs: Int) {
                executeMpv {
                    mpv.setPropertyDouble(
                        "audio-delay",
                        delayMs.coerceIn(AUDIO_DELAY_MIN_MS, AUDIO_DELAY_MAX_MS) / 1000.0,
                    )
                }
            }

            override val supportsAudioAmplification = true

            override fun setAudioAmplificationDb(db: Int) {
                executeMpv {
                    mpv.setPropertyDouble("volume", 100.0 * audioAmplificationGain(db))
                }
            }
        }

    /**
     * Loads the local subtitle file at [path] in place of the external track loaded from
     * [replacedUrl], under that track's label and language. Earlier AutoSync copies are dropped too.
     */
    fun replaceExternalSubtitle(replacedUrl: String, path: String) {
        executeMpv {
            fun externalSubtitleTracks() = mpv.getPropertyNode("track-list")?.asArray()?.toList().orEmpty()
                .filter { node -> node.nodeString("type") == "sub" && node.nodeBoolean("external") == true }

            val replacedSource = replacedUrl.toMpvSource()
            val earlierCopyPrefix = "${path.substringBeforeLast('/')}/$LIBMPV_AUTOSYNC_FILE_PREFIX"
            val replaced = externalSubtitleTracks()
                .lastOrNull { node -> node.nodeString("external-filename") == replacedSource }
            val title = replaced?.let { node ->
                node.nodeString("title") ?: node.nodeString("external-filename")?.substringAfterLast('/')
            }
            val language = replaced?.nodeString("lang")
            when {
                title != null && language != null -> mpv.command("sub-add", path, "cached", title, language)
                title != null -> mpv.command("sub-add", path, "cached", title)
                else -> mpv.command("sub-add", path, "cached")
            }
            externalSubtitleTracks()
                .filter { node ->
                    val filename = node.nodeString("external-filename") ?: return@filter false
                    filename != path &&
                        (filename == replacedSource || filename.startsWith(earlierCopyPrefix))
                }
                .mapNotNull { node -> node.nodeInt("id") }
                .forEach { id -> mpv.command("sub-remove", id.toString()) }
        }
    }

    fun refreshTracks(context: Context) {
        executeMpv {
            latestAudioTracks = extractLibmpvTracks(context, type = "audio")
            latestSubtitleTracks = extractLibmpvTracks(context, type = "sub")
        }
    }

    private fun setPausedNow(paused: Boolean) {
        runCatching { mpv.setPropertyBoolean("pause", paused) }
    }

    private fun applyRequestHeadersNow(headers: Map<String, String>) {
        val userAgent = headers.entries.firstOrNull { it.key.equals("User-Agent", ignoreCase = true) }?.value
        if (!userAgent.isNullOrBlank()) {
            InAppLogger.debug("MPV/Android", "Applying User-Agent header")
            mpv.setPropertyString("user-agent", userAgent)
        }
        val serialized = headers
            .filterKeys { !it.equals("User-Agent", ignoreCase = true) }
            .map { (key, value) -> "${key}: ${value.replace(",", "\\,")}" }
            .joinToString(",")
        if (headers.isNotEmpty()) {
            InAppLogger.debug(
                "MPV/Android",
                "Applying request header keys=${InAppLogger.headerKeys(headers)}",
            )
        }
        mpv.setPropertyString("http-header-fields", serialized)
    }

    private fun extractLibmpvTracks(context: Context, type: String): List<LibmpvTrack> {
        val nodes = mpv.getPropertyNode("track-list")?.asArray()?.toList().orEmpty()
        return nodes
            .filter { node -> node.nodeString("type") == type }
            .mapIndexedNotNull { index, node ->
                val id = node.nodeInt("id") ?: return@mapIndexedNotNull null
                val rawLabel = node.nodeString("title")
                    ?: node.nodeString("external-filename")?.substringAfterLast('/')
                    ?: node.nodeString("codec")
                val language = node.nodeString("lang") ?: normalizeLanguageCode(rawLabel)
                val label = rawLabel?.takeIf { it.isNotBlank() }
                    ?: runBlocking { getString(Res.string.compose_player_track_number, index + 1) }
                LibmpvTrack(
                    id = id,
                    label = label,
                    language = language,
                    isSelected = node.nodeBoolean("selected") ?: false,
                    isForced = inferForcedSubtitleTrack(
                        label = label,
                        language = language,
                        trackId = id.toString(),
                        hasForcedSelectionFlag = node.nodeBoolean("forced") ?: false,
                    ),
                )
            }
    }
}

private data class LibmpvTrack(
    val id: Int,
    val label: String,
    val language: String?,
    val isSelected: Boolean,
    val isForced: Boolean,
)


private fun ExoPlayer.logSelectedPlaybackDetails(context: String) {
    val selectedVideo = selectedFormatFor(C.TRACK_TYPE_VIDEO)
    val selectedAudio = selectedFormatFor(C.TRACK_TYPE_AUDIO)
    val selectedText = selectedFormatFor(C.TRACK_TYPE_TEXT)

    InAppLogger.info(
        "ExoPlayer/Android",
        "selectedTracks context=$context " +
            "video=${selectedVideo?.toTrackLogSummary(C.TRACK_TYPE_VIDEO) ?: "none"} " +
            "audio=${selectedAudio?.toTrackLogSummary(C.TRACK_TYPE_AUDIO) ?: "none"} " +
            "subtitle=${selectedText?.toTrackLogSummary(C.TRACK_TYPE_TEXT) ?: "none"}",
    )
}

private fun ExoPlayer.selectedFormatFor(trackType: Int): Format? =
    currentTracks.groups.firstOrNull { group ->
        group.type == trackType && group.isSelected && group.mediaTrackGroup.length > 0
    }?.mediaTrackGroup?.getFormat(0)

private fun Format.toTrackLogSummary(trackType: Int): String =
    buildString {
        append("mime=")
        append(sampleMimeType ?: "unknown")
        append(" codec=")
        append(codecs ?: "unknown")
        if (!id.isNullOrBlank()) append(" id=$id")
        if (!label.isNullOrBlank()) append(" label=$label")
        if (!language.isNullOrBlank()) append(" lang=$language")
        when (trackType) {
            C.TRACK_TYPE_VIDEO -> {
                append(" resolution=")
                append(if (width > 0 && height > 0) "${width}x$height" else "unknown")
                if (frameRate > 0f) append(" fps=${frameRate.formatOneDecimal()}")
                if (bitrate > 0) append(" bitrate=${bitrate.toLong().formatBitrate()}")
                append(" dynamicRange=${dynamicRangeSummary()}")
            }
            C.TRACK_TYPE_AUDIO -> {
                if (channelCount > 0) append(" channels=$channelCount")
                if (sampleRate > 0) append(" sampleRate=${sampleRate}Hz")
                if (bitrate > 0) append(" bitrate=${bitrate.toLong().formatBitrate()}")
            }
        }
    }

private fun Format.dynamicRangeSummary(): String {
    val codecString = codecs.orEmpty().lowercase()
    if (sampleMimeType == MimeTypes.VIDEO_DOLBY_VISION || codecString.contains("dvhe") || codecString.contains("dvh1")) {
        return "DolbyVision"
    }
    val info = colorInfo ?: return "unknown"
    return when (info.colorTransfer) {
        C.COLOR_TRANSFER_ST2084 -> {
            if (codecString.contains("hdr10+")) "HDR10+" else "HDR10/PQ"
        }
        C.COLOR_TRANSFER_HLG -> "HLG"
        C.COLOR_TRANSFER_SDR -> "SDR"
        else -> "transfer=${info.colorTransfer} space=${info.colorSpace} range=${info.colorRange}"
    }
}

private fun VideoSize.toLogSummary(): String =
    buildString {
        append(width)
        append('x')
        append(height)
        if (unappliedRotationDegrees != 0) append(" rotation=$unappliedRotationDegrees")
        if (pixelWidthHeightRatio != 1f) append(" pixelRatio=${pixelWidthHeightRatio.formatOneDecimal()}")
    }

private fun Int.decoderPriorityName(): String =
    when (this) {
        DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF -> "OFF"
        DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON -> "ON"
        DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER -> "PREFER"
        else -> toString()
    }

private fun String.decoderAccelerationHint(): String {
    val value = lowercase()
    return when {
        value.contains("omx.google") || value.contains("c2.android") || value.contains("ffmpeg") || value.contains("software") -> "software"
        value.contains("omx.") || value.contains("c2.") || value.contains("mediacodec") -> "hardware"
        else -> "unknown"
    }
}

private fun Long.formatBitrate(): String =
    when {
        this <= 0L -> "unknown"
        this >= 1_000_000L -> "${(this / 1_000_000.0).formatOneDecimal()}Mbps"
        this >= 1_000L -> "${(this / 1_000.0).formatOneDecimal()}Kbps"
        else -> "${this}bps"
    }

private fun Long.formatBytes(): String =
    when {
        this >= 1024L * 1024L -> "${(this / (1024.0 * 1024.0)).formatOneDecimal()}MiB"
        this >= 1024L -> "${(this / 1024.0).formatOneDecimal()}KiB"
        else -> "${this}B"
    }

private fun Float.formatOneDecimal(): String =
    ((this * 10f).toInt() / 10f).toString()

private fun Double.formatOneDecimal(): String =
    ((this * 10.0).toInt() / 10.0).toString()

private fun MPVNode.toMpvNodeSummary(): String =
    runCatching { toString() }
        .getOrElse { "<unavailable>" }
        .let { if (it.length <= 240) it else it.take(240) + "…" }

private const val LIBMPV_MAX_VOLUME_PERCENT = 400

private fun libmpvCacheBytes(): Int =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) 64 * 1024 * 1024 else 32 * 1024 * 1024

private fun Int.logIfMpvError(option: String) {
    if (this < 0) {
        Log.w(TAG, "libmpv option failed: $option status=$this")
        InAppLogger.warn("MPV/Android", "libmpv option failed: $option status=$this")
    }
}

private fun String.redactedPlaybackUrlForLogs(maxLength: Int = 180): String {
    val withoutQuery = substringBefore('?')
    return if (withoutQuery.length <= maxLength) {
        withoutQuery
    } else {
        withoutQuery.take(maxLength) + "…"
    }
}

private fun Double?.toMillis(): Long =
    this?.takeIf { it.isFinite() && it > 0.0 }?.let { (it * 1000.0).toLong() } ?: 0L

private fun MPVNode.nodeString(key: String): String? =
    runCatching { this[key]?.asString() }.getOrNull()?.takeIf { it.isNotBlank() }

private fun MPVNode.nodeInt(key: String): Int? =
    runCatching { this[key]?.asInt()?.toInt() }.getOrNull()

private fun MPVNode.nodeBoolean(key: String): Boolean? =
    runCatching { this[key]?.asBoolean() }.getOrNull()

private fun androidx.compose.ui.graphics.Color.toMpvColor(): String {
    val argb = toArgb()
    val alpha = (argb ushr 24) and 0xff
    val red = (argb shr 16) and 0xff
    val green = (argb shr 8) and 0xff
    val blue = argb and 0xff
    return "#%02X%02X%02X%02X".format(alpha, red, green, blue)
}

private fun androidx.compose.ui.graphics.Color.alphaByte(): Int =
    (toArgb() ushr 24) and 0xff

private fun SubtitleStyleState.toMpvSubtitleFontSize(): Int =
    (fontSizeSp * MPV_SUBTITLE_FONT_SIZE_SCALE).toInt().coerceIn(
        MPV_SUBTITLE_FONT_SIZE_MIN,
        MPV_SUBTITLE_FONT_SIZE_MAX,
    )

private fun SubtitleStyleState.toMpvSubtitleOutlineSize(): Int =
    if (!outlineEnabled) 0 else (outlineWidth * MPV_SUBTITLE_OUTLINE_SIZE_SCALE).toInt().coerceAtLeast(1)

private fun SubtitleStyleState.toMpvSubtitleBorderStyle(): String =
    if (outlineEnabled) {
        "outline-and-shadow"
    } else if (backgroundColor.alphaByte() > 0) {
        "opaque-box"
    } else {
        "outline-and-shadow"
    }

private const val MPV_SUBTITLE_FONT_SIZE_SCALE = 55.0 / 18.0
private const val MPV_SUBTITLE_FONT_SIZE_MIN = 36
private const val MPV_SUBTITLE_FONT_SIZE_MAX = 122
private const val MPV_SUBTITLE_OUTLINE_SIZE_SCALE = 1.5

private class ExoMediaInfoCache {
    private var tracks: androidx.media3.common.Tracks? = null
    private var mediaItem: MediaItem? = null
    private var videoFormat: androidx.media3.common.Format? = null
    private var audioFormat: androidx.media3.common.Format? = null
    private var videoDecoder: String? = null
    private var audioDecoder: String? = null
    private var json: String? = null

    fun get(player: ExoPlayer, videoDecoder: String?, audioDecoder: String?): String {
        val currentTracks = player.currentTracks
        val currentMediaItem = player.currentMediaItem
        val currentVideoFormat = player.videoFormat
        val currentAudioFormat = player.audioFormat
        val cached = json
        if (
            cached != null &&
            currentTracks === tracks &&
            currentMediaItem === mediaItem &&
            currentVideoFormat === videoFormat &&
            currentAudioFormat === audioFormat &&
            videoDecoder == this.videoDecoder &&
            audioDecoder == this.audioDecoder
        ) {
            return cached
        }
        val built = player.buildExoPlayerMediaInfoJson(videoDecoder, audioDecoder)
        tracks = currentTracks
        mediaItem = currentMediaItem
        videoFormat = currentVideoFormat
        audioFormat = currentAudioFormat
        this.videoDecoder = videoDecoder
        this.audioDecoder = audioDecoder
        json = built
        return built
    }
}

private data class AnimeToggles(
    val androidAnimeUpscaleEnabled: Boolean,
    val androidAnimeLineSharpenEnabled: Boolean,
)

private fun PlayerSettingsUiState.animeToggles() = AnimeToggles(
    androidAnimeUpscaleEnabled = androidAnimeUpscaleEnabled,
    androidAnimeLineSharpenEnabled = androidAnimeLineSharpenEnabled,
)

@Composable
private fun rememberAnimeToggles(): androidx.compose.runtime.State<AnimeToggles> {
    val toggles = remember {
        PlayerSettingsRepository.uiState
            .map { it.animeToggles() }
            .distinctUntilChanged()
    }
    return toggles.collectAsState(initial = PlayerSettingsRepository.uiState.value.animeToggles())
}

private const val ANIME_EFFECTS_REBUILD_DEBOUNCE_MS = 700L

private class ExoVideoEffectsHolder {
    @Volatile
    var pipelineConfigured = false
        private set
    @Volatile
    var animeBuilt = false
        private set
    @Volatile
    private var upscaleEnabled = false
    @Volatile
    private var lineSharpenEnabled = false

    fun update(
        pipelineConfigured: Boolean,
        animeBuilt: Boolean,
        upscaleEnabled: Boolean,
        lineSharpenEnabled: Boolean,
    ) {
        this.pipelineConfigured = pipelineConfigured
        this.animeBuilt = animeBuilt
        this.upscaleEnabled = upscaleEnabled
        this.lineSharpenEnabled = lineSharpenEnabled
    }

    fun matches(upscaleEnabled: Boolean, lineSharpenEnabled: Boolean): Boolean =
        this.upscaleEnabled == upscaleEnabled && this.lineSharpenEnabled == lineSharpenEnabled

    fun libassRenderMode(configuredMode: String): String =
        if (animeBuilt) "VIDEO_EFFECT" else configuredMode
}

private fun androidx.media3.common.Tracks.hasSelectedAssWithoutDolbyVision(): Boolean {
    val hasSelectedAss = groups.any { group ->
        group.isSelected && group.type == C.TRACK_TYPE_TEXT &&
            (0 until group.length).any { i ->
                group.isTrackSelected(i) && group.getTrackFormat(i).isAssSubtitleFormat()
            }
    }
    val hasDvVideo = groups.any { group ->
        group.isSelected && group.type == C.TRACK_TYPE_VIDEO &&
            (0 until group.length).any { i ->
                group.getTrackFormat(i).sampleMimeType == MimeTypes.VIDEO_DOLBY_VISION
            }
    }
    return hasSelectedAss && !hasDvVideo
}

private fun androidx.media3.common.Tracks.selectedTextTrackOrdinal(): Int {
    var ordinal = 0
    var selected = -1
    for (group in groups) {
        if (group.type != C.TRACK_TYPE_TEXT) continue
        for (i in 0 until group.length) {
            if (group.isTrackSelected(i)) selected = ordinal
            ordinal++
        }
    }
    return selected
}

private fun ExoPlayer.snapshot(
    videoDecoder: String?,
    audioDecoder: String?,
    chapters: List<PlayerChapter> = emptyList(),
    mediaInfoCache: ExoMediaInfoCache? = null,
): PlayerPlaybackSnapshot {
    val (videoWidth, videoHeight) = videoDimensions()
    return PlayerPlaybackSnapshot(
        isLoading = playbackState == Player.STATE_IDLE || playbackState == Player.STATE_BUFFERING,
        isPlaying = isPlaying,
        isEnded = playbackState == Player.STATE_ENDED,
        durationMs = duration.coerceAtLeast(0L),
        positionMs = currentPosition.coerceAtLeast(0L),
        bufferedPositionMs = bufferedPosition.coerceAtLeast(0L),
        playbackSpeed = playbackParameters.speed,
        videoWidth = videoWidth,
        videoHeight = videoHeight,
        mediaInfoJson = mediaInfoCache?.get(this, videoDecoder, audioDecoder)
            ?: buildExoPlayerMediaInfoJson(videoDecoder, audioDecoder),
        chapters = chapters,
    )
}

private fun ExoPlayer.videoDimensions(): Pair<Int, Int> {
    val format = videoFormat ?: return videoSize.width to videoSize.height
    val hasCrop = format.decodedWidth != Format.NO_VALUE &&
        format.decodedHeight != Format.NO_VALUE &&
        (format.decodedWidth > format.width || format.decodedHeight > format.height)
    val baseWidth = if (hasCrop) format.width else (format.width.takeIf { it > 0 } ?: videoSize.width)
    val baseHeight = if (hasCrop) format.height else (format.height.takeIf { it > 0 } ?: videoSize.height)
    val ratio = format.pixelWidthHeightRatio
    return if (ratio != 1f) (baseWidth * ratio).roundToInt() to baseHeight else baseWidth to baseHeight
}


private fun ExoPlayer.buildExoPlayerMediaInfoJson(videoDecoder: String?, audioDecoder: String?): String {
    return try {
        val videoFormat = selectedPlaybackInfoFormat(C.TRACK_TYPE_VIDEO)
        val audioFormat = selectedPlaybackInfoFormat(C.TRACK_TYPE_AUDIO)
        val filename = currentMediaItem
            ?.localConfiguration
            ?.uri
            ?.toString()
            ?.substringBefore('?')
            ?.substringAfterLast('/')
            .orEmpty()

        buildString {
            append('{')
            appendJsonString("engine", "ExoPlayer")
            append(',')
            appendJsonString("filename", filename)
            append(',')

            if (videoFormat != null) {
                val videoCodec = videoFormat.codecs ?: videoFormat.sampleMimeType.orEmpty()
                appendJsonString("videoCodec", videoCodec)
                append(',')
                append("\"videoWidth\":").append(videoFormat.width.coerceAtLeast(0)).append(',')
                append("\"videoHeight\":").append(videoFormat.height.coerceAtLeast(0)).append(',')
                append("\"fps\":").append(if (videoFormat.frameRate > 0f) videoFormat.frameRate else 0f).append(',')
                append("\"videoBitrateKbps\":").append(if (videoFormat.bitrate > 0) videoFormat.bitrate / 1000 else 0).append(',')
                appendJsonString("videoDecoder", videoDecoder.orEmpty())
                append(',')
                appendJsonString("hwdecCurrent", videoDecoder?.decoderAccelerationHint().orEmpty())
                append(',')
                appendJsonString("hdrFormat", videoFormat.hdrFormatForPlaybackInfo())
                append(',')
                appendJsonString("dvProfile", videoFormat.dolbyVisionProfileForPlaybackInfo())
                append(',')
                appendJsonString("codecProfile", videoFormat.sampleMimeType.orEmpty())
                append(',')
                appendJsonString("gamma", videoFormat.transferFunctionForPlaybackInfo())
                append(',')
                appendJsonString("primaries", videoFormat.colorPrimariesForPlaybackInfo())
                append(',')
                appendJsonString("pixelFormat", "")
                append(',')
            } else {
                appendJsonString("videoCodec", "")
                append(',')
                append("\"videoWidth\":0,\"videoHeight\":0,\"fps\":0,\"videoBitrateKbps\":0,")
                appendJsonString("videoDecoder", "")
                append(',')
                appendJsonString("hwdecCurrent", "")
                append(',')
                appendJsonString("hdrFormat", "")
                append(',')
                appendJsonString("dvProfile", "")
                append(',')
                appendJsonString("codecProfile", "")
                append(',')
                appendJsonString("gamma", "")
                append(',')
                appendJsonString("primaries", "")
                append(',')
                appendJsonString("pixelFormat", "")
                append(',')
            }

            if (audioFormat != null) {
                val audioCodec = audioFormat.codecs ?: audioFormat.sampleMimeType.orEmpty()
                appendJsonString("audioCodec", audioCodec)
                append(',')
                appendJsonString("audioDecoder", audioDecoder.orEmpty())
                append(',')
                appendJsonString("audioChannels", audioFormat.channelCount.takeIf { it > 0 }?.toString().orEmpty())
                append(',')
                appendJsonString("audioSampleRate", audioFormat.sampleRate.takeIf { it > 0 }?.toString().orEmpty())
                append(',')
                appendJsonString("audioLang", audioFormat.language.orEmpty())
                append(',')
                append("\"audioBitrateKbps\":").append(if (audioFormat.bitrate > 0) audioFormat.bitrate / 1000 else 0)
            } else {
                appendJsonString("audioCodec", "")
                append(',')
                appendJsonString("audioDecoder", "")
                append(',')
                appendJsonString("audioChannels", "")
                append(',')
                appendJsonString("audioSampleRate", "")
                append(',')
                appendJsonString("audioLang", "")
                append(',')
                append("\"audioBitrateKbps\":0")
            }
            append('}')
        }
    } catch (error: Throwable) {
        InAppLogger.warn("ExoPlayer/Android", "Failed to build playback info: ${InAppLogger.throwableSummary(error)}")
        "{}"
    }
}

private fun ExoPlayer.selectedPlaybackInfoFormat(trackType: Int): Format? {
    for (group in currentTracks.groups) {
        if (group.type != trackType || !group.isSelected) continue
        for (index in 0 until group.length) {
            if (group.isTrackSelected(index)) {
                return group.mediaTrackGroup.getFormat(index)
            }
        }
    }
    return null
}

private fun Format.hdrFormatForPlaybackInfo(): String {
    val codecString = codecs.orEmpty().lowercase()
    if (sampleMimeType == MimeTypes.VIDEO_DOLBY_VISION || codecString.contains("dvhe") || codecString.contains("dvh1")) {
        return "dolby_vision"
    }
    val info = colorInfo ?: return ""
    return when (info.colorTransfer) {
        C.COLOR_TRANSFER_ST2084 -> if (codecString.contains("hdr10+")) "hdr10_plus" else "hdr"
        C.COLOR_TRANSFER_HLG -> "hlg"
        C.COLOR_TRANSFER_SDR -> "sdr"
        else -> ""
    }
}

private fun Format.dolbyVisionProfileForPlaybackInfo(): String {
    val codecString = codecs.orEmpty().lowercase()
    val prefix = when {
        codecString.contains("dvhe") -> "dvhe"
        codecString.contains("dvh1") -> "dvh1"
        else -> return ""
    }
    val profile = codecString.substringAfter("$prefix.", missingDelimiterValue = "")
        .substringBefore('.')
        .takeIf { it.isNotBlank() }
    return profile?.toIntOrNull()?.let { "Profile $it" } ?: profile.orEmpty()
}

private fun Format.transferFunctionForPlaybackInfo(): String =
    when (colorInfo?.colorTransfer) {
        C.COLOR_TRANSFER_ST2084 -> "pq"
        C.COLOR_TRANSFER_HLG -> "hlg"
        C.COLOR_TRANSFER_SDR -> "sdr"
        else -> ""
    }

private fun Format.colorPrimariesForPlaybackInfo(): String =
    when (colorInfo?.colorSpace) {
        C.COLOR_SPACE_BT2020 -> "bt.2020"
        C.COLOR_SPACE_BT709 -> "bt.709"
        C.COLOR_SPACE_BT601 -> "bt.601"
        else -> ""
    }

private fun StringBuilder.appendJsonString(key: String, value: String) {
    append('"').append(key).append("\":\"").append(value.escapeJson()).append('"')
}

private fun String.escapeJson(): String =
    replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace("\t", "\\t")

private fun ExoPlayer.shouldKeepPlayerScreenOn(): Boolean =
    playerError == null &&
        playWhenReady &&
        playbackState in setOf(Player.STATE_BUFFERING, Player.STATE_READY)

private data class TrackSelectionSnapshot(
    val trackType: Int,
    val index: Int,
    val id: String?,
    val language: String?,
    val label: String?,
    val sampleMimeType: String?,
    val codecs: String?,
    val channelCount: Int,
    val roleFlags: Int,
)

private fun ExoPlayer.captureSelectedTrack(trackType: Int): TrackSelectionSnapshot? {
    var idx = 0
    for (group in currentTracks.groups) {
        if (group.type != trackType) continue
        if (group.isSelected) {
            val format = group.mediaTrackGroup.getFormat(0)
            return TrackSelectionSnapshot(
                trackType = trackType,
                index = idx,
                id = format.id,
                language = format.language,
                label = format.label,
                sampleMimeType = format.sampleMimeType,
                codecs = format.codecs,
                channelCount = format.channelCount,
                roleFlags = format.roleFlags,
            )
        }
        idx++
    }
    return null
}

private fun ExoPlayer.restoreTrackSelection(selection: TrackSelectionSnapshot): Boolean {
    selection.id?.takeIf { it.isNotBlank() }?.let { id ->
        val restored = selectTrackByPredicate(selection.trackType, "id=$id") { _, format ->
            format.id == id
        }
        if (restored) {
            return true
        }
    }

    selection.label?.takeIf { it.isNotBlank() }?.let { label ->
        val restored = selectTrackByPredicate(selection.trackType, "label=$label") { _, format ->
            format.label.equals(label, ignoreCase = true) &&
                (selection.language.isNullOrBlank() ||
                    format.language.equals(selection.language, ignoreCase = true))
        }
        if (restored) {
            return true
        }
    }

    val technicalMatchIndexes = mutableListOf<Int>()
    var idx = 0
    for (group in currentTracks.groups) {
        if (group.type != selection.trackType) continue
        val format = group.mediaTrackGroup.getFormat(0)
        if (
            !selection.language.isNullOrBlank() &&
            format.language.equals(selection.language, ignoreCase = true) &&
            format.sampleMimeType == selection.sampleMimeType &&
            format.codecs == selection.codecs &&
            format.channelCount == selection.channelCount &&
            format.roleFlags == selection.roleFlags
        ) {
            technicalMatchIndexes.add(idx)
        }
        idx++
    }
    if (technicalMatchIndexes.size == 1) {
        return selectTrackByIndex(selection.trackType, technicalMatchIndexes.first())
    }

    return selectTrackByIndex(selection.trackType, selection.index)
}

private val LIVE_PROBE_ERROR_CODES = setOf(
    PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
    PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
    PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED,
    PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
)

private fun PlaybackException.isDecoderFailure(): Boolean =
    errorCode in setOf(
        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
        PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,
        PlaybackException.ERROR_CODE_DECODING_FAILED,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
        PlaybackException.ERROR_CODE_DECODING_RESOURCES_RECLAIMED,
    )

private fun PlayerResizeMode.toExoResizeMode(): Int =
    when (this) {
        PlayerResizeMode.Fit -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        PlayerResizeMode.Fill -> AspectRatioFrameLayout.RESIZE_MODE_FILL
        PlayerResizeMode.Zoom -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    }

private fun PlayerView.syncLibassOverlay(
    player: ExoPlayer,
    enabled: Boolean,
    renderMode: String = "VIDEO_EFFECT",
    tunnelingEnabled: Boolean = false,
) {
    // Atlas pipeline always draws through AssSubtitleSurfaceView in the top-level overlay container.
    val containerId = R.id.libass_overlay_container_gl
    val overlayContainer = findViewById<android.widget.FrameLayout>(containerId) ?: return
    // Overlay is needed only in OVERLAY render mode or tunneled playback.
    // VIDEO_EFFECT draws subtitles directly onto each video frame - no overlay needed.
    val needsOverlay = enabled && (renderMode == "OVERLAY" || tunnelingEnabled)
    val boundPlayer = getTag(R.id.libass_overlay_bound_player) as? ExoPlayer
    val hasOverlayChild = overlayContainer.hasAssOverlayChild()

    if (!needsOverlay) {
        if (hasOverlayChild) {
            overlayContainer.removeAssOverlayChildren()
        }
        if (boundPlayer != null) {
            boundPlayer.getAssHandlerCompat()?.videoFrameCallback = null
            setTag(R.id.libass_overlay_bound_player, null)
        }
        return
    }

    val assHandler = player.getAssHandlerCompat() ?: return
    if (boundPlayer === player && hasOverlayChild) {
        return
    }

    overlayContainer.removeAssOverlayChildren()
    val assSubtitleView = AssSubtitleSurfaceView(overlayContainer.context, assHandler)
    // Wire video frame callback to drive subtitle rendering.
    // The primary path (VideoFrameMetadataListener) provides vsync-pinned timing.
    // When it doesn't fire (tunneled playback), AssPositionRenderer in the
    // RenderersFactory provides position-based fallback on every render loop.
    assHandler.videoFrameCallback = { presentationTimeUs, releaseTimeNs ->
        assSubtitleView.requestRender(presentationTimeUs, releaseTimeNs)
    }
    overlayContainer.addView(
        assSubtitleView,
        android.widget.FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
    )
    setTag(R.id.libass_overlay_bound_player, player)
    ensureLibassOverlayLayoutSync()
    post { syncLibassOverlayGeometry() }
}

private fun PlayerView.ensureLibassOverlayLayoutSync() {
    if (getTag(R.id.libass_overlay_layout_listener) != null) return
    val listener = View.OnLayoutChangeListener { _, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom ->
        if (left != oldLeft || top != oldTop || right != oldRight || bottom != oldBottom) {
            syncLibassOverlayGeometry()
        }
    }
    findViewById<AspectRatioFrameLayout>(androidx.media3.ui.R.id.exo_content_frame)?.addOnLayoutChangeListener(listener)
    findViewById<android.widget.FrameLayout>(R.id.libass_overlay_container_gl)?.addOnLayoutChangeListener(listener)
    setTag(R.id.libass_overlay_layout_listener, listener)
}
private fun android.widget.FrameLayout.hasAssOverlayChild(): Boolean {
    for (index in 0 until childCount) {
        if (getChildAt(index) is AssSubtitleSurfaceView) {
            return true
        }
    }
    return false
}

private fun android.widget.FrameLayout.removeAssOverlayChildren() {
    for (index in childCount - 1 downTo 0) {
        if (getChildAt(index) is AssSubtitleSurfaceView) {
            removeViewAt(index)
        }
    }
}

private fun PlayerView.releaseLibassOverlay() {
    findViewById<android.widget.FrameLayout>(R.id.libass_overlay_container_gl)
        ?.removeAssOverlayChildren()
    setTag(R.id.libass_overlay_bound_player, null)
}

private const val PIP_FALLBACK_SUBTITLE_SCALE = 0.4f

/** Height of a fitted video inside [viewSize], or null if either size is unknown. */
private fun displayedVideoHeightPx(viewSize: IntSize, videoSize: VideoSize): Float? {
    if (viewSize.width <= 0 || viewSize.height <= 0 || videoSize.width <= 0 || videoSize.height <= 0) return null
    val videoAspect = videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height
    return minOf(viewSize.height.toFloat(), viewSize.width / videoAspect)
}

/**
 * Remembers the last subtitle style applied to a [PlayerView] so the style is not set again on
 * every snapshot.
 */
private class SubtitleStyleGuard {
    private var view: PlayerView? = null
    private var style: SubtitleStyleState? = null
    private var pipVideoHeightPx: Float? = null

    fun shouldApply(view: PlayerView, style: SubtitleStyleState, pipVideoHeightPx: Float?): Boolean {
        if (this.view === view && this.style == style && this.pipVideoHeightPx == pipVideoHeightPx) {
            return false
        }
        this.view = view
        this.style = style
        this.pipVideoHeightPx = pipVideoHeightPx
        return true
    }
}

/**
 * [pipVideoHeightPx] is null outside PiP. In PiP it is the video height outside PiP (0 if unknown),
 * so subtitles shrink and grow with the video exactly as it is shown full screen.
 */

private fun transformedChildBoundsInParent(child: View): android.graphics.RectF? {
    if (child.width <= 0 || child.height <= 0) return null
    return android.graphics.RectF(0f, 0f, child.width.toFloat(), child.height.toFloat()).also { bounds ->
        child.matrix.mapRect(bounds)
        bounds.offset(child.left.toFloat(), child.top.toFloat())
    }
}

private data class LibassOverlayMargins(
    val top: Int,
    val bottom: Int,
    val left: Int,
    val right: Int
)

private fun libassOverlayMargins(
    overlayWidth: Int,
    overlayHeight: Int,
    videoBounds: android.graphics.RectF
): LibassOverlayMargins? {
    if (
        overlayWidth <= 0 || overlayHeight <= 0 ||
        !videoBounds.left.isFinite() || !videoBounds.top.isFinite() ||
        !videoBounds.right.isFinite() || !videoBounds.bottom.isFinite() ||
        videoBounds.width() <= 0f || videoBounds.height() <= 0f
    ) {
        return null
    }
    return LibassOverlayMargins(
        top = videoBounds.top.roundToInt(),
        bottom = (overlayHeight - videoBounds.bottom).roundToInt(),
        left = videoBounds.left.roundToInt(),
        right = (overlayWidth - videoBounds.right).roundToInt()
    )
}

/**
 * Computes the distance from the libass overlay frame to the visible video rectangle
 * using the actual transformed bounds of exo_content_frame, then applies them to
 * AssHandler. Only runs when the overlay SurfaceView exists (OVERLAY render mode).
 */
private fun PlayerView.syncLibassOverlayGeometry() {
    val overlay = findViewById<android.widget.FrameLayout>(R.id.libass_overlay_container_gl)
    val assOverlayView = overlay?.findAssOverlayChild()
    val contentFrame = findViewById<AspectRatioFrameLayout>(androidx.media3.ui.R.id.exo_content_frame)
    val exoPlayer = player as? ExoPlayer
    val assHandler = exoPlayer?.getAssHandlerCompat()

    if (assOverlayView == null || assHandler == null || contentFrame == null) return

    val overlayWidth = overlay?.width ?: 0
    val overlayHeight = overlay?.height ?: 0
    val videoBounds = transformedChildBoundsInParent(contentFrame) ?: return
    val margins = libassOverlayMargins(overlayWidth, overlayHeight, videoBounds) ?: return

    assHandler.setMargins(margins.top, margins.bottom, margins.left, margins.right)
    assHandler.setUseMargins(false)
    assOverlayView.invalidateSubtitles()
}

private fun android.widget.FrameLayout.findAssOverlayChild(): AssSubtitleSurfaceView? {
    for (index in 0 until childCount) {
        val child = getChildAt(index)
        if (child is AssSubtitleSurfaceView) {
            return child
        }
    }
    return null
}

/**
 * [pipVideoHeightPx] is null outside PiP. In PiP it is the video height outside PiP (0 if unknown),
 * so subtitles shrink and grow with the video exactly as it is shown full screen.
 */
private fun PlayerView.applySubtitleStyle(style: SubtitleStyleState, pipVideoHeightPx: Float? = null) {
    subtitleView?.apply {
        val baseBottomPaddingFraction = SubtitleView.DEFAULT_BOTTOM_PADDING_FRACTION * 2f / 3f
        val offsetFraction = (style.bottomOffset / 1000f).coerceIn(0f, 0.2f)
        val bottomPaddingFraction = (baseBottomPaddingFraction + offsetFraction).coerceIn(0f, 0.4f)

        setApplyEmbeddedStyles(false)
        setApplyEmbeddedFontSizes(false)
        setBottomPaddingFraction(bottomPaddingFraction)
        setStyle(
            CaptionStyleCompat(
                style.textColor.toArgb(),
                style.backgroundColor.toArgb(),
                android.graphics.Color.TRANSPARENT,
                if (style.outlineEnabled) CaptionStyleCompat.EDGE_TYPE_OUTLINE else CaptionStyleCompat.EDGE_TYPE_NONE,
                style.outlineColor.toArgb(),
                if (style.bold) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT,
            )
        )
        val fontSizeSp = style.fontSizeSp.toFloat()
        when {
            pipVideoHeightPx == null -> setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, fontSizeSp)
            // The PiP window matches the video, so a fraction of its height follows window resizes.
            pipVideoHeightPx > 0f -> setFractionalTextSize(
                TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, fontSizeSp, resources.displayMetrics) /
                    pipVideoHeightPx,
            )
            // Full-screen size unknown: fall back to a fixed PiP scale.
            else -> setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, fontSizeSp * PIP_FALLBACK_SUBTITLE_SCALE)
        }
    }
}

/**
 * A downloaded file is read from disk, so it needs a much smaller buffer than a stream.
 * `content:` URIs that do not come from a download provider point at local files too.
 */
private fun MediaItem.isLocalFileSource(): Boolean {
    val uri = localConfiguration?.uri ?: return false
    return when (uri.scheme?.lowercase()) {
        "file" -> true
        "content" -> !uri.authority.orEmpty().contains("downloads", ignoreCase = true)
        else -> false
    }
}

/**
 * Cheap fingerprint of the player's audio groups and their selection. The full track list is
 * only rebuilt when this signature changes, so the runtime tick does not allocate a new list.
 */
private fun ExoPlayer.audioTrackSignature(): String {
    val signature = StringBuilder()
    for (group in currentTracks.groups) {
        if (group.type != C.TRACK_TYPE_AUDIO) continue
        signature.append(group.length).append(':')
            .append(group.isSelected).append(':')
        val trackCount = group.mediaTrackGroup.length
        if (trackCount > 0) {
            val format = group.mediaTrackGroup.getFormat(0)
            signature.append(format.id).append(':').append(format.language)
        }
        signature.append(';')
    }
    return signature.toString()
}

/** Caches the audio track list and rebuilds it only when the track signature changes. */
private class AudioTrackCache {
    private var signature: String? = null
    private var tracks: List<AudioTrack> = emptyList()

    fun tracks(player: ExoPlayer, context: Context): List<AudioTrack> {
        val currentSignature = player.audioTrackSignature()
        if (currentSignature != signature) {
            signature = currentSignature
            tracks = player.extractAudioTracks(context)
        }
        return tracks
    }
}

private fun ExoPlayer.extractAudioTracks(context: Context): List<AudioTrack> {
    val tracks = mutableListOf<AudioTrack>()
    val trackNameProvider = CustomDefaultTrackNameProvider(context.resources)
    var idx = 0
    for (group in currentTracks.groups) {
        if (group.type != C.TRACK_TYPE_AUDIO) continue
        val format = group.mediaTrackGroup.getFormat(0)
        val label = trackNameProvider.getTrackName(format).takeIf { it.isNotBlank() }
            ?: runBlocking { getString(Res.string.compose_player_track_number, idx + 1) }
        tracks.add(
            AudioTrack(
                index = idx,
                id = format.id ?: idx.toString(),
                label = label,
                language = format.language,
                isSelected = group.isSelected,
            )
        )
        idx++
    }
    return tracks
}

private fun ExoPlayer.applySubtitleTrackPreferences(
    preferredLanguage: String,
    useForcedSubtitles: Boolean,
    autoSelectionApplied: Boolean,
    hasActiveSubtitle: Boolean,
    useCustomSubtitles: Boolean,
) {
    if ((hasActiveSubtitle || useCustomSubtitles) && autoSelectionApplied) {
        return
    }

    val builder = trackSelectionParameters.buildUpon()
    val resolvedPreferred = exoPreferredTextLanguage(preferredLanguage)

    if (resolvedPreferred == null) {
        builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        builder.setPreferredTextLanguage(null)
    } else {
        val userDisabledSubtitles = autoSelectionApplied && !hasActiveSubtitle
        val shouldSuppressExoAutoSelect = useForcedSubtitles && !autoSelectionApplied
        if (!userDisabledSubtitles && !shouldSuppressExoAutoSelect) {
            builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
        }
        if (!shouldSuppressExoAutoSelect) {
            builder.setPreferredTextLanguage(resolvedPreferred)
        }
    }

    val currentFlags = trackSelectionParameters.ignoredTextSelectionFlags
    val newFlags = if (!useForcedSubtitles) {
        currentFlags or C.SELECTION_FLAG_FORCED
    } else {
        currentFlags and C.SELECTION_FLAG_FORCED.inv()
    }
    builder.setIgnoredTextSelectionFlags(newFlags)
    trackSelectionParameters = builder.build()
}

private fun exoPreferredTextLanguage(preferredLanguage: String): String? {
    val normalized = normalizeLanguageCode(preferredLanguage) ?: return null
    return when (normalized) {
        SubtitleLanguageOption.NONE,
        SubtitleLanguageOption.FORCED,
        -> null
        SubtitleLanguageOption.DEVICE ->
            DeviceLanguagePreferences.preferredLanguageCodes().firstOrNull()
        else -> normalized
    }
}

private fun ExoPlayer.extractSubtitleTracks(context: Context): List<SubtitleTrack> {
    val tracks = mutableListOf<SubtitleTrack>()
    val trackNameProvider = CustomDefaultTrackNameProvider(context.resources)
    var idx = 0
    for (group in currentTracks.groups) {
        if (group.type != C.TRACK_TYPE_TEXT) continue
        val format = group.mediaTrackGroup.getFormat(0)
        val hasForcedSelectionFlag = (format.selectionFlags and C.SELECTION_FLAG_FORCED) != 0
        tracks.add(
            SubtitleTrack(
                index = idx,
                id = format.id ?: idx.toString(),
                label = trackNameProvider.getTrackName(format),
                language = format.language,
                isSelected = group.isSelected,
                isForced = inferForcedSubtitleTrack(
                    label = format.label,
                    language = format.language,
                    trackId = format.id,
                    hasForcedSelectionFlag = hasForcedSelectionFlag,
                ),
            )
        )
        idx++
    }
    return tracks
}

private fun ExoPlayer.selectTrackByIndex(trackType: Int, targetIndex: Int): Boolean {
    return selectTrackByPredicate(trackType, "index=$targetIndex") { idx, _ ->
        idx == targetIndex
    }
}

private fun ExoPlayer.selectTrackByPredicate(
    trackType: Int,
    targetDescription: String,
    predicate: (index: Int, format: Format) -> Boolean,
): Boolean {
    val typeName = if (trackType == C.TRACK_TYPE_AUDIO) "AUDIO" else "TEXT"
    Log.d(TAG, "selectTrack: type=$typeName target=$targetDescription")
    var idx = 0
    for (group in currentTracks.groups) {
        if (group.type != trackType) continue
        val format = group.mediaTrackGroup.getFormat(0)
        if (!predicate(idx, format)) {
            idx++
            continue
        }
        Log.d(TAG, "selectTrack: found group at idx=$idx, format.id=${format.id}, lang=${format.language}, label=${format.label}")
        trackSelectionParameters = trackSelectionParameters
            .buildUpon()
            .setOverrideForType(
                TrackSelectionOverride(group.mediaTrackGroup, listOf(0))
            )
            .build()
        Log.d(TAG, "selectTrack: override applied")
        return true
    }
    Log.w(TAG, "selectTrack: no group found for type=$typeName target=$targetDescription (total groups scanned=$idx)")
    return false
}

private val lastInAppTrackDump = java.util.WeakHashMap<ExoPlayer, String>()

private fun ExoPlayer.logCurrentTracks(context: String) {
    Log.d(TAG, "--- logCurrentTracks ($context) ---")
    val textDisabled = trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
    Log.d(TAG, "  textDisabled=$textDisabled")

    val groupLines = mutableListOf<Pair<Boolean, String>>()
    for (group in currentTracks.groups) {
        val typeName = when (group.type) {
            C.TRACK_TYPE_AUDIO -> "AUDIO"
            C.TRACK_TYPE_TEXT -> "TEXT"
            C.TRACK_TYPE_VIDEO -> "VIDEO"
            else -> "OTHER(${group.type})"
        }
        if (group.mediaTrackGroup.length <= 0) continue
        val format = group.mediaTrackGroup.getFormat(0)
        val message = "group type=$typeName selected=${group.isSelected} supported=${group.isSupported} " +
            format.toTrackLogSummary(group.type)
        Log.d(TAG, "  $message")
        if (group.type == C.TRACK_TYPE_VIDEO || group.type == C.TRACK_TYPE_AUDIO || group.type == C.TRACK_TYPE_TEXT) {
            groupLines += group.isSelected to message
        }
    }
    Log.d(TAG, "--- end logCurrentTracks ---")

    val dump = "textDisabled=$textDisabled\n" + groupLines.joinToString("\n") { it.second }
    val unchanged = synchronized(lastInAppTrackDump) {
        (lastInAppTrackDump[this] == dump).also { if (!it) lastInAppTrackDump[this] = dump }
    }
    if (unchanged) {
        InAppLogger.debug("ExoPlayer/Android", "tracks context=$context unchanged")
        return
    }
    InAppLogger.debug("ExoPlayer/Android", "tracks context=$context textDisabled=$textDisabled groups=${currentTracks.groups.size}")
    for ((selected, message) in groupLines) {
        if (selected) {
            InAppLogger.info("ExoPlayer/Android", message)
        } else {
            InAppLogger.debug("ExoPlayer/Android", message)
        }
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
internal fun playerBoostLinearGain(level: Float): Float {
    val clamped = level.coerceIn(0f, 2f)
    if (clamped <= 1f) return clamped
    return 10f.pow((clamped - 1f) * PLAYER_MAX_BOOST_DB / 20f)
}

private const val PLAYER_MAX_BOOST_DB = 12f
private const val LIBMPV_VOLUME_MAX = 200

private class PlayerOutputAudioProcessor(
    private val stereoDownmixEnabled: Boolean,
) : BaseAudioProcessor() {
    @Volatile
    var level: Float = 1f
        set(value) {
            field = value.coerceIn(0f, 2f)
        }

    @Volatile
    var nightModeEnabled: Boolean = false

    private var downmix = false
    private var limiterGain = 1f
    private var releaseCoefficient = 0f
    private var nightLevel = 0f
    private var nightGain = 1f
    private var nightAttackCoefficient = 0f
    private var nightReleaseCoefficient = 0f
    private var frameMeanSquare = 0f
    private val frame = FloatArray(MAX_CHANNELS)

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) return AudioProcessor.AudioFormat.NOT_SET
        val channels = inputAudioFormat.channelCount
        if (channels <= 0 || channels > MAX_CHANNELS) return AudioProcessor.AudioFormat.NOT_SET
        downmix = stereoDownmixEnabled && (channels == 6 || channels == 8)
        releaseCoefficient = 1f - exp(-1f / (LIMITER_RELEASE_SECONDS * inputAudioFormat.sampleRate))
        nightAttackCoefficient = 1f - exp(-1f / (NIGHT_ATTACK_SECONDS * inputAudioFormat.sampleRate))
        nightReleaseCoefficient = 1f - exp(-1f / (NIGHT_RELEASE_SECONDS * inputAudioFormat.sampleRate))
        return if (downmix) {
            AudioProcessor.AudioFormat(inputAudioFormat.sampleRate, 2, C.ENCODING_PCM_16BIT)
        } else {
            inputAudioFormat
        }
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val inputChannels = inputAudioFormat.channelCount
        val outputChannels = outputAudioFormat.channelCount
        val input = inputBuffer.order(ByteOrder.nativeOrder())
        val frames = input.remaining() / (2 * inputChannels)
        val output = replaceOutputBuffer(frames * outputChannels * 2).order(ByteOrder.nativeOrder())
        val gain = playerBoostLinearGain(level)
        val night = nightModeEnabled

        if (!downmix && gain == 1f && !night && limiterGain >= 1f) {
            val bytes = frames * inputChannels * 2
            val slice = input.duplicate()
            slice.limit(slice.position() + bytes)
            output.put(slice)
        } else {
            repeat(frames) {
                if (downmix) {
                    readFrame(input, inputChannels)
                    downmixToStereo(inputChannels)
                } else {
                    readFrame(input, inputChannels)
                }
                var frameGain = gain
                if (night) {
                    val coefficient = if (frameMeanSquare > nightLevel) nightAttackCoefficient else nightReleaseCoefficient
                    nightLevel += (frameMeanSquare - nightLevel) * coefficient
                    if (it % NIGHT_CONTROL_FRAMES == 0) nightGain = nightCompressorGain(nightLevel)
                    frameGain *= nightGain
                }
                var peak = 0f
                for (channel in 0 until outputChannels) {
                    val boosted = frame[channel] * frameGain
                    frame[channel] = boosted
                    val magnitude = abs(boosted)
                    if (magnitude > peak) peak = magnitude
                }
                if (peak * limiterGain > LIMITER_CEILING) {
                    limiterGain = LIMITER_CEILING / peak
                } else {
                    limiterGain += (1f - limiterGain) * releaseCoefficient
                    if (limiterGain > 0.9999f) limiterGain = 1f
                }
                for (channel in 0 until outputChannels) {
                    val sample = (frame[channel] * limiterGain * Short.MAX_VALUE)
                        .roundToInt()
                        .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                    output.putShort(sample.toShort())
                }
            }
        }

        input.position(input.limit())
        output.flip()
    }

    private fun readFrame(input: ByteBuffer, channels: Int) {
        var sum = 0f
        for (channel in 0 until channels) {
            val sample = input.short / SHORT_SCALE
            frame[channel] = sample
            sum += sample * sample
        }
        frameMeanSquare = sum / channels
    }

    private fun nightCompressorGain(meanSquare: Float): Float {
        val over = 10f * log10(maxOf(meanSquare, 1e-10f)) - NIGHT_THRESHOLD_DB
        val gainDb = NIGHT_MAKEUP_DB - maxOf(over, 0f) * (1f - 1f / NIGHT_RATIO)
        return 10f.pow(gainDb / 20f)
    }

    private fun downmixToStereo(channels: Int) {
        val frontLeft = frame[0]
        val frontRight = frame[1]
        val center = frame[2]
        var surroundLeft = frame[4]
        var surroundRight = frame[5]
        if (channels == 8) {
            surroundLeft += frame[6]
            surroundRight += frame[7]
        }
        frame[0] = DOWNMIX_SCALE * (frontLeft + center + SURROUND_COEFFICIENT * surroundLeft)
        frame[1] = DOWNMIX_SCALE * (frontRight + center + SURROUND_COEFFICIENT * surroundRight)
    }

    override fun onFlush() {
        limiterGain = 1f
        nightLevel = 0f
        nightGain = 1f
    }

    override fun onReset() {
        limiterGain = 1f
        downmix = false
        nightLevel = 0f
        nightGain = 1f
    }

    private companion object {
        const val MAX_CHANNELS = 24
        const val SHORT_SCALE = 32768f
        const val LIMITER_CEILING = 0.94f
        const val LIMITER_RELEASE_SECONDS = 0.15f
        const val SURROUND_COEFFICIENT = 0.707f
        const val DOWNMIX_SCALE = 0.8f
        const val NIGHT_THRESHOLD_DB = -24f
        const val NIGHT_RATIO = 6f
        const val NIGHT_MAKEUP_DB = 12f
        const val NIGHT_ATTACK_SECONDS = 0.005f
        const val NIGHT_RELEASE_SECONDS = 0.3f
        const val NIGHT_CONTROL_FRAMES = 32
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
private class PcmOnlyAudioSink(sink: AudioSink) : ForwardingAudioSink(sink) {
    override fun supportsFormat(format: Format): Boolean =
        getFormatSupport(format) != AudioSink.SINK_FORMAT_UNSUPPORTED

    override fun getFormatSupport(format: Format): Int {
        if (format.sampleMimeType != MimeTypes.AUDIO_RAW) return AudioSink.SINK_FORMAT_UNSUPPORTED
        return super.getFormatSupport(format)
    }
}

private fun PlayerView.videoBoundsFraction(aspectRatio: Float): RectF? {
    val subtitleView = this.subtitleView ?: return null
    val viewWidth = subtitleView.width.toFloat()
    val viewHeight = subtitleView.height.toFloat()
    if (viewWidth <= 0f || viewHeight <= 0f) return null

    if (aspectRatio > 0f) {
        val parentRatio = viewWidth / viewHeight
        return if (parentRatio > aspectRatio) {
            val fitW = viewHeight * aspectRatio
            val leftPx = (viewWidth - fitW) / 2f
            RectF(leftPx / viewWidth, 0f, (leftPx + fitW) / viewWidth, 1f)
        } else {
            val fitH = viewWidth / aspectRatio
            val topPx = (viewHeight - fitH) / 2f
            RectF(0f, topPx / viewHeight, 1f, (topPx + fitH) / viewHeight)
        }
    }

    val contentFrame = getTag(androidx.media3.ui.R.id.exo_content_frame) as? AspectRatioFrameLayout
        ?: findViewById<AspectRatioFrameLayout>(androidx.media3.ui.R.id.exo_content_frame)
            ?.also { setTag(androidx.media3.ui.R.id.exo_content_frame, it) }
        ?: return null
    val frameWidth = contentFrame.width.toFloat()
    val frameHeight = contentFrame.height.toFloat()
    if (frameWidth <= 0f || frameHeight <= 0f) return null
    if (frameWidth > viewWidth || frameHeight > viewHeight) return null
    val left = contentFrame.x / viewWidth
    val top = contentFrame.y / viewHeight
    return RectF(
        left,
        top,
        left + frameWidth / viewWidth,
        top + frameHeight / viewHeight,
    )
}

/**
 * Layout the app's FFmpeg audio decoder mixes surround audio down to. [normalize] lowers the mix
 * so it cannot clip, at the cost of overall volume.
 */
private data class FfmpegAudioDownmix(
    val channels: AudioOutputChannels,
    val normalize: Boolean,
)

@androidx.annotation.OptIn(UnstableApi::class)
private class SubtitleOffsetRenderersFactory(
    context: Context,
    private val subtitleDelayUsProvider: () -> Long,
    private val audioDelayUsProvider: () -> Long,
    private val audioAmplificationDbProvider: () -> Int,
    private val audioDownmix: FfmpegAudioDownmix?,
    private val preferAppAudioDecoder: Boolean,
    private val centerMixLevelDbProvider: () -> Int,
    private val onFfmpegAudioRenderer: (FfmpegAudioRenderer?) -> Unit,
    private val shouldNormalizeCuePositionProvider: () -> Boolean,
    private val shouldStripSdhProvider: () -> Boolean,
    private val volumeBoostAudioProcessor: PlayerOutputAudioProcessor,
    private val audioPassthroughEnabled: Boolean,
    private val presentCues: (List<Cue>) -> List<Cue>,
    private val videoBoundsFractionProvider: () -> RectF?,
) : DefaultRenderersFactory(context) {
    override fun buildAudioSink(
        context: Context,
        enableFloatOutput: Boolean,
        enableAudioTrackPlaybackParams: Boolean,
    ): AudioSink {
        // Fork: 16-bit output (PlayerOutputAudioProcessor works on PCM16) and the PCM-only sink
        // unless passthrough is on. Upstream's amplification runs first, the fork's processor
        // (downmix, volume boost, peak limiter) last so its limiter also catches the gain.
        val sink = DefaultAudioSink.Builder(context)
            .setEnableFloatOutput(false)
            .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
            .setAudioProcessors(arrayOf(GainAudioProcessor(audioAmplificationDbProvider), volumeBoostAudioProcessor))
            .build()
        return if (audioPassthroughEnabled) sink else PcmOnlyAudioSink(sink)
    }

    override fun buildVideoRenderers(
        context: Context,
        extensionRendererMode: Int,
        mediaCodecSelector: MediaCodecSelector,
        enableDecoderFallback: Boolean,
        eventHandler: Handler,
        eventListener: VideoRendererEventListener,
        allowedVideoJoiningTimeMs: Long,
        out: ArrayList<Renderer>,
    ) {
        super.buildVideoRenderers(
            context,
            extensionRendererMode,
            mediaCodecSelector,
            enableDecoderFallback,
            eventHandler,
            eventListener,
            allowedVideoJoiningTimeMs,
            out,
        )
        if (extensionRendererMode == EXTENSION_RENDERER_MODE_OFF) return
        out.add(
            SoftwareVideoRenderer(
                allowedVideoJoiningTimeMs,
                eventHandler,
                eventListener,
                MAX_DROPPED_VIDEO_FRAME_COUNT_TO_NOTIFY,
            ),
        )
    }

    override fun buildAudioRenderers(
        context: Context,
        extensionRendererMode: Int,
        mediaCodecSelector: MediaCodecSelector,
        enableDecoderFallback: Boolean,
        audioSink: AudioSink,
        eventHandler: Handler,
        eventListener: AudioRendererEventListener,
        out: ArrayList<Renderer>,
    ) {
        val startIndex = out.size
        super.buildAudioRenderers(
            context,
            if (preferAppAudioDecoder) DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER else extensionRendererMode,
            DolbyFreeMediaCodecSelector(mediaCodecSelector),
            enableDecoderFallback,
            audioSink,
            eventHandler,
            eventListener,
            out,
        )
        val ffmpegRenderer = out.subList(startIndex, out.size).filterIsInstance<FfmpegAudioRenderer>().firstOrNull()
        ffmpegRenderer?.run {
            if (audioDownmix != null) {
                setAudioOutputChannels(audioDownmix.channels.ffmpegLayoutName, audioDownmix.channels.channelCount)
                setDownmixNormalizationEnabled(audioDownmix.normalize)
            } else {
                setAudioOutputChannels(null, 0)
                setDownmixNormalizationEnabled(false)
            }
            setCenterMixLevelDb(centerMixLevelDbProvider())
        }
        onFfmpegAudioRenderer(ffmpegRenderer)
    }

    override fun buildTextRenderers(
        context: Context,
        output: TextOutput,
        outputLooper: android.os.Looper,
        extensionRendererMode: Int,
        out: ArrayList<Renderer>,
    ) {
        val normalizingOutput = CueNormalizingTextOutput(
            delegate = output,
            shouldNormalizeCuePositionProvider = shouldNormalizeCuePositionProvider,
            shouldStripSdhProvider = shouldStripSdhProvider,
            presentCues = presentCues,
            videoBoundsFractionProvider = videoBoundsFractionProvider,
        )
        val startIndex = out.size
        super.buildTextRenderers(context, normalizingOutput, outputLooper, extensionRendererMode, out)
        for (index in startIndex until out.size) {
            out[index] = SubtitleOffsetRenderer(
                baseRenderer = out[index],
                subtitleDelayUsProvider = subtitleDelayUsProvider,
                audioDelayUsProvider = audioDelayUsProvider,
            )
        }
    }
}

/**
 * Hides the crashing platform Dolby decoders (e.g. `c2.dolby.eac3.decoder.eac3`) from the
 * MediaCodec audio renderer so the bundled ffmpeg extension renderer handles AC-3/E-AC-3
 * (including E-AC-3 JOC) from the very first prepare attempt instead of failing once and retrying.
 */
@androidx.annotation.OptIn(UnstableApi::class)
private class DolbyFreeMediaCodecSelector(
    private val delegate: MediaCodecSelector,
) : MediaCodecSelector {
    override fun getDecoderInfos(
        mimeType: String,
        requiresSecureDecoder: Boolean,
        requiresTunnelingDecoder: Boolean,
    ): List<MediaCodecInfo> {
        val decoderInfos = delegate.getDecoderInfos(
            mimeType,
            requiresSecureDecoder,
            requiresTunnelingDecoder,
        )
        if (mimeType != MimeTypes.AUDIO_AC3 &&
            mimeType != MimeTypes.AUDIO_E_AC3 &&
            mimeType != MimeTypes.AUDIO_E_AC3_JOC
        ) {
            return decoderInfos
        }
        return decoderInfos.filterNot { it.name.contains("dolby", ignoreCase = true) }
    }
}

private class CueNormalizingTextOutput(
    private val delegate: TextOutput,
    private val shouldNormalizeCuePositionProvider: () -> Boolean,
    private val shouldStripSdhProvider: () -> Boolean,
    private val presentCues: (List<Cue>) -> List<Cue>,
    private val videoBoundsFractionProvider: () -> RectF?,
) : TextOutput {
    override fun onCues(cueGroup: CueGroup) {
        val processed = cueGroup.cues.mapNotNull(::processCue)
        delegate.onCues(CueGroup(presentCues(processed), cueGroup.presentationTimeUs))
    }

    @Deprecated("Uses the deprecated Media3 callback for text outputs.")
    override fun onCues(cues: List<Cue>) {
        delegate.onCues(presentCues(cues.mapNotNull(::processCue)))
    }

    private fun processCue(cue: Cue): Cue? {
        var processed = fixRtlCueText(cue)
        if (shouldStripSdhProvider()) {
            val text = processed.text?.toString() ?: return processed
            val filtered = SubtitleSdhFilter.filter(text) ?: return null
            if (filtered != text) {
                processed = processed.buildUpon().setText(filtered).build()
            }
        }
        if (shouldNormalizeCuePositionProvider()) {
            processed = normalizeCuePosition(processed)
        }
        if (processed.bitmap != null) {
            val bounds = videoBoundsFractionProvider()
            if (bounds != null && bounds.width() > 0f && bounds.height() > 0f) {
                val isIdentity = bounds.left == 0f && bounds.top == 0f
                    && bounds.width() == 1f && bounds.height() == 1f
                if (!isIdentity) {
                    processed = remapBitmapCueToVideoBounds(processed, bounds)
                }
            }
        }
        return processed
    }

    private fun remapBitmapCueToVideoBounds(cue: Cue, bounds: RectF): Cue {
        val builder = cue.buildUpon()
        if (cue.position != Cue.DIMEN_UNSET) {
            builder.setPosition(bounds.left + cue.position * bounds.width())
        }
        if (cue.size != Cue.DIMEN_UNSET) {
            builder.setSize(cue.size * bounds.width())
        }
        if (cue.lineType == Cue.LINE_TYPE_FRACTION && cue.line != Cue.DIMEN_UNSET) {
            builder.setLine(bounds.top + cue.line * bounds.height(), Cue.LINE_TYPE_FRACTION)
        }
        if (cue.bitmapHeight != Cue.DIMEN_UNSET) {
            builder.setBitmapHeight(cue.bitmapHeight * bounds.height())
        }
        return builder.build()
    }

    private fun normalizeCuePosition(cue: Cue): Cue {
        if (cue.bitmap != null || cue.verticalType != Cue.TYPE_UNSET || cue.line == Cue.DIMEN_UNSET) {
            return cue
        }
        return cue.buildUpon()
            .setLine(Cue.DIMEN_UNSET, Cue.TYPE_UNSET)
            .setLineAnchor(Cue.TYPE_UNSET)
            .build()
    }

    private fun fixRtlCueText(cue: Cue): Cue {
        val text = cue.text ?: return cue
        if (!containsRtlChars(text)) return cue
        val original = text.toString()
        val fixed = original.split('\n').joinToString("\n") { line ->
            moveLeadingRtlPunctuationToEnd(line)
        }
        if (fixed == original) return cue
        return cue.buildUpon().setText(SpannableString(fixed)).build()
    }

    private fun moveLeadingRtlPunctuationToEnd(line: String): String {
        if (line.isEmpty()) return line
        var end = 0
        while (end < line.length && line[end] in RTL_PUNCTUATION) end++
        if (end == 0) return line
        return line.substring(end) + line.substring(0, end)
    }

    private fun containsRtlChars(text: CharSequence): Boolean {
        for (char in text) {
            val directionality = Character.getDirectionality(char)
            if (
                directionality == Character.DIRECTIONALITY_RIGHT_TO_LEFT ||
                directionality == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC
            ) {
                return true
            }
        }
        return false
    }

    companion object {
        private val RTL_PUNCTUATION = setOf('.', ',', '?', '!', '-', ':', ';', '…', ')', '(')
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
private class SubtitleOffsetRenderer(
    baseRenderer: Renderer,
    private val subtitleDelayUsProvider: () -> Long,
    private val audioDelayUsProvider: () -> Long,
) : ForwardingRenderer(baseRenderer) {
    override fun render(positionUs: Long, elapsedRealtimeUs: Long) {
        // The audio delay moves video ahead of the audio clock; subtitles follow the video.
        val adjustedPositionUs = (positionUs + audioDelayUsProvider() - subtitleDelayUsProvider()).coerceAtLeast(0L)
        super.render(adjustedPositionUs, elapsedRealtimeUs)
    }
}

private fun diagnosticElapsedSince(startedAtMs: Long): Long =
    if (startedAtMs <= 0L) -1L else (SystemClock.elapsedRealtime() - startedAtMs).coerceAtLeast(0L)

private fun diagnosticPlaybackSource(value: String): String = runCatching {
    val uri = Uri.parse(value)
    val host = uri.host.orEmpty()
    val isLoopback = host == "127.0.0.1" || host == "localhost" || host == "::1"
    "scheme=${uri.scheme ?: "none"},host=${host.ifBlank { "none" }},port=${uri.port},loopback=$isLoopback"
}.getOrDefault("unparseable")

private fun isLoopbackPlaybackSource(value: String): Boolean = runCatching {
    when (Uri.parse(value).host.orEmpty().lowercase()) {
        "127.0.0.1", "localhost", "::1" -> true
        else -> false
    }
}.getOrDefault(false)

private fun diagnosticPlayerMessage(value: String?): String =
    value?.replace('\n', ' ')?.replace('\r', ' ')?.take(160) ?: "none"

private fun diagnosticThrowableChain(value: Throwable): String =
    generateSequence(value) { it.cause }
        .take(6)
        .joinToString(" -> ") { error ->
            "${error.javaClass.simpleName}:${diagnosticPlayerMessage(error.message)}"
        }
        .let(::diagnosticPlayerMessage)

internal class SubtitleRequestHeaderDataSourceFactory(
    private val upstreamFactory: DataSource.Factory,
    private val externalSubtitles: List<com.nuvio.app.features.streams.StreamSubtitle>,
) : DataSource.Factory {
    override fun createDataSource(): DataSource =
        SubtitleRequestHeaderDataSource(
            upstream = upstreamFactory.createDataSource(),
            externalSubtitles = externalSubtitles,
        )
}

internal class SubtitleRequestHeaderDataSource(
    private val upstream: DataSource,
    private val externalSubtitles: List<com.nuvio.app.features.streams.StreamSubtitle>,
) : DataSource {
    override fun addTransferListener(transferListener: TransferListener) {
        upstream.addTransferListener(transferListener)
    }

    override fun open(dataSpec: DataSpec): Long {
        val url = dataSpec.uri.toString()
        val subtitle = externalSubtitles.find { it.url == url }
        val headers = subtitle?.headers
        
        return if (headers.isNullOrEmpty()) {
            upstream.open(dataSpec)
        } else {
            val mergedHeaders = dataSpec.httpRequestHeaders.toMutableMap()
            headers.forEach { (key, value) ->
                mergedHeaders[key] = value
            }
            upstream.open(dataSpec.buildUpon().setHttpRequestHeaders(mergedHeaders).build())
        }
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int =
        upstream.read(buffer, offset, length)

    override fun getUri(): Uri? = upstream.uri

    override fun getResponseHeaders(): Map<String, List<String>> = upstream.responseHeaders

    override fun close() {
        upstream.close()
    }
}

private fun exoVideoCodec(video: Format?): String? {
    if (video == null) return null
    val mime = video.sampleMimeType
    // For Dolby Vision the mime is always video/dolby-vision regardless of the base codec.
    // Resolve the actual base codec from the codecs string prefix.
    if (mime == MimeTypes.VIDEO_DOLBY_VISION) {
        val c = video.codecs.orEmpty().lowercase()
        return when {
            c.startsWith("dvhe") || c.startsWith("dvh1") -> "HEVC"
            c.startsWith("dvav") || c.startsWith("dva1") -> "AVC"
            c.startsWith("dav1") -> "AV1"
            else -> "HEVC" // safe default for unknown DV profiles
        }
    }
    return CustomDefaultTrackNameProvider.resolveCodecName(mime, video.codecs)
}

private fun Format.hdrFormats(): List<String> = buildList {
    val lowerCodecs = codecs.orEmpty().lowercase()
    if (sampleMimeType == MimeTypes.VIDEO_DOLBY_VISION
        || lowerCodecs.contains("dvhe") || lowerCodecs.contains("dvh1")
        || lowerCodecs.contains("dvav")
        || lowerCodecs.contains("dav1") || lowerCodecs.contains("dva1")
    ) {
        add("DV")
    }
    when (colorInfo?.colorTransfer) {
        C.COLOR_TRANSFER_ST2084 -> add("HDR10")
        C.COLOR_TRANSFER_HLG -> add("HLG")
    }
}

private val DTS_HD_MA_LABEL = Regex("""\b(ma|master audio)\b""")

private fun exoAudioProfiles(audio: Format?): List<String> {
    if (audio == null) return emptyList()
    val mime = audio.sampleMimeType.orEmpty().lowercase()
    val codecs = audio.codecs.orEmpty().lowercase()
    val label = audio.label.orEmpty().lowercase()
    val combined = "$codecs $label"
    return buildList {
        if (combined.contains("atmos")) add("Atmos")
        if (combined.contains("dts:x") || combined.contains("dtsx")
            || mime == MimeTypes.AUDIO_DTS_X) add("DTS:X")
        val isDtsHd = combined.contains("dts-hd") || combined.contains("dtshd")
            || codecs.startsWith("dtsh") || codecs.startsWith("dtsl")
        if (codecs.startsWith("dtsl") || (isDtsHd && DTS_HD_MA_LABEL.containsMatchIn(combined))) add("DTS-HD MA")
        else if (isDtsHd) add("DTS-HD")
    }
}

private fun Format.exoBitDepth(): Int? {
    colorInfo?.lumaBitdepth?.takeIf { it > 0 }?.let { return it }
    val c = codecs.orEmpty().lowercase()
    return when {
        c.startsWith("hev1.2.") || c.startsWith("hvc1.2.") -> 10
        c.contains("dvhe") || c.contains("dvh1") -> 10 // DV profile 5/7/8: 10-bit HEVC
        c.startsWith("dav1") -> 10 // DV profile 10: 10-bit AV1
        // dvav/dva1 (DV profile 9) is 8-bit AVC — no fallback needed
        else -> null
    }
}
